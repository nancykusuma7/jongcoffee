<?php
include 'logout.php'; 
?>
<div class="row">
   
<!-- ================================================================================== Gambar -->
          <div id="carousel-example-generic" class="carousel slide" data-ride="carousel"> 
            <ol class="carousel-indicators">
              <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
              <li data-target="#carousel-example-generic" data-slide-to="1"></li>
              <li data-target="#carousel-example-generic" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner"> 
              <div class="item active"> <img class="slide-image" src="assets/images/slide-image1.jpg" alt=""> 
              </div>
              <div class="item"> <img class="slide-image" src="assets/images/slide-image2.jpg" alt=""> 
              </div>
              <div class="item"> <img class="slide-image" src="assets/images/slide-image3.jpg" alt=""> 
              </div>
            </div>
            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev"> 
            <span class="glyphicon glyphicon-chevron-left"></span> </a> <a class="right carousel-control" href="#carousel-example-generic" data-slide="next"> 
            <span class="glyphicon glyphicon-chevron-right"></span> </a> </div>


<nav class="navbar navbar-default" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">

        <!-- Menu kiri -->
        <ul class="nav navbar-nav">

<li style="margin-top: 15px"><font color='#ffffff'><strong>Welcome to Waroeng Kopi Jong Pekalongan</strong></font></li>

       </ul> 

        <!-- Menu kanan -->
        <ul class="nav navbar-nav navbar-right" style="padding-right: 15px">

           
<?php 
      if(!EMPTY($_SESSION['meja'])) { ?>
      <li style="margin-right: 20px"><a href="index">HOME</a></li>
      <li style="margin-right: 20px"><a href="menu?meja=<?php echo $_SESSION['meja'];?>"><?php echo $_SESSION['meja'];?></a></li>
      <li style="margin-right: 20px"><a href="inbox?meja=<?php echo $_SESSION['meja'];?>">CHAT</a></li>
      <li style="margin-right: 20px"><a href="daftar_pembelian?meja=<?php echo $_SESSION['meja'];?>">PESANAN</a></li>
    <?php } ?>
            <!-- Pelanggan sudah login -->
            
        </ul>
    </div>
    <!-- /.navbar-collapse -->
</nav>

