<?php
include('koneksi.php');

$kd_produk = $_GET['kd_produk'];
$ukuran = $_GET['ukuran'];
$sql     = $con->query("SELECT * FROM stok WHERE kd_produk='$kd_produk' AND ukuran = '$ukuran'");
$row     = $sql->fetch();
$trow    = $sql->rowCount();

if (empty($trow)) {
    $stok  = 0;
    $kd_stok  = 0;
} else {
	$stok  = $row['stok'];
	$kd_stok  = $row['kd_stok'];
}

$output = array(
    'stok' =>$stok,
    'kd_stok' =>$kd_stok
);

echo json_encode($output);
?>