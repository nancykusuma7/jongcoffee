<?php 
include 'config.php';
include 'koneksi.php';
include 'assets/lib/function.php';
include 'assets/lib/rajaongkir.php';
include 'query_header.php';

$meja = $_SESSION['meja'];
$pesanan = $_SESSION['kd_pesanan'];


if ((isset($_POST["edit"])) && ($_POST["edit"] == "y")) {
	$harga 	= $_POST['harga'];
	$jml_beli    = $_POST['jml'];
	//$kd_stok     = $_POST['kd_stok'];
	//$stok_semula = $_POST['stok_semula'];
	$order       = $_POST['order'];
	$jmlharga 	= $harga*$jml_beli;
	//$faktur      = $_POST['faktur'];
	//$stok_baru   = $stok_semula-$jml_beli;

	// $con->exec("UPDATE stok SET stok='$stok_semula' WHERE kd_stok='$kd_stok' ");
    $con->exec("UPDATE order_menu SET jml='$jml_beli', jmlharga='$jmlharga' WHERE kd_order_menu='$order'");
    // $con->exec("UPDATE stok SET stok=stok-$jml_beli WHERE kd_stok='$kd_stok' ");

	header("Location: daftar_pembelian");
}


if ((isset($_POST["hapus"])) && ($_POST["hapus"] == "y")) {
	//$jml_beli        = $_POST['jml_beli'];
	$kd_order_menu = $_POST['kd_order_menu'];
	//$kd_stok         = $_POST['kd_stok'];

	// $con->exec("UPDATE stok SET stok=stok+$jml_beli WHERE kd_stok='$kd_stok' ");
	$con->exec("DELETE FROM order_menu WHERE kd_order_menu='$kd_order_menu' ");
}

//============================================== */
if ((isset($_POST["edit_alamat"])) && ($_POST["edit_alamat"] == "y")) {

	$nama_plg     = $_POST['nama_plg'];
	$alamat_plg   = $_POST['alamat_plg'];
	$tlp_plg      = $_POST['tlp_plg'];
	$userid	      = $_POST['email'];
	
	
	$con->exec("INSERT INTO pelanggan (userid, nama_plg, alamat_plg, tlp_plg) 
            VALUES (
	            '".$userid."',
	            '".$nama_plg ."',
	            '".$alamat_plg."',
	            '".$tlp_plg."'
            )");
	$con->exec("UPDATE pesanan SET userid='$userid' WHERE kd_pesanan='$pesanan'");
	header("Location: daftar_pembelian");
}

$sql_pesanan = $con->query("SELECT * FROM pesanan WHERE meja='$meja' AND konfirm='Belum'");
$row_pesanan = $sql_pesanan->fetch(PDO::FETCH_LAZY);
$pesanan = $row_pesanan['kd_pesanan'];
$userid = $row_pesanan['userid'];
$trow_pesanan = $sql_pesanan->rowCount();
$sql_order_produk = $con->query("SELECT a.*, b.* FROM order_menu as a, menu as b WHERE a.meja='$meja' AND a.kd_pesanan='$pesanan' AND b.kd_menu=a.kd_menu");
$row_order_produk = $sql_order_produk->fetch(PDO::FETCH_LAZY);
$trow_order_produk = $sql_order_produk->rowCount();

$sql_plg = $con->query("SELECT * FROM pelanggan WHERE userid='$userid'");
$row_plg = $sql_plg->fetch(PDO::FETCH_LAZY);
$jml_barang = 0;
//$jml_berat = 0;
$sub_total = 0;


$jkonfirm = "";

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="shortcut icon" href="assets/images/icon.jpg" />
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/toko.css">
        <link rel="stylesheet" href="assets/fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/jquery.bootstrap-touchspin.min.css">
    </head>
    <body>

        <div class="container" style="margin-bottom: 150px">
        <?php include 'header.php'; ?>


            <div class="row">

                <div class="col-md-12">
                <div id="judul">Daftar Pesanan</div>
	            	<ol class="breadcrumb">
						<li><a href="./">Home</a></li>
						<li class="active">Daftar Pesanan</li>
					</ol>
                    <hr>
					
					<?php if (!empty($trow_order_produk )): ?>
                    <div class="row">
						<!-- 
						=========================================================== Pilih Metode Pembayaran -->
												<!-- 
						=========================================================== Pilih Kurir -->
	                    <div class="col-xs-6">
							<h4 class="pull-right">Faktur Pesanan : <span style="color: red"><?php echo $pesanan ?></span></h4>
	                    </div>
                    </div>
							<h5>Identitas Pelanggan : </h5>
									<div class="row" style="margin-bottom: 20px">
										<div class="col-xs-3">
											Nama Pelanggan:<br>
											Alamat:<br>
											Telepon:<br>
											Email:<br>										
										</div>
										<div class="col-xs-9">
											<?php echo $row_plg['nama_plg']; ?><br>
											<?php echo $row_plg['alamat_plg']; ?><br>
											<?php echo $row_plg['tlp_plg']; ?><br>
											<?php echo $row_plg['userid']; ?><br>
										</div>
									</div>
									<a href="#ubah-alamat" data-toggle="modal" class="btn btn-info btn-sm"> Ubah</a><p>&nbsp</p>
					<table class="table table-bordered table-hover" style="font-size: 12px">
						<thead>
							<tr>
								<th colspan="2">
									<h4>Daftar Menu</h4>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php do{
										
										$kd_menu = $row_order_produk['kd_menu'];
										
							?>
							<tr>
								<td>
									<div class="media">
										<div class="media-left">
											<div class="gproduk-sm">
												<img src="assets/images/menu/<?php echo $row_order_produk['foto']; ?>" width="100" >
											</div>
										</div>
										<div class="media-body" data-id="<?php echo $row_order_produk['kd_menu'];?>">
											<h5 class="media-heading"><?php echo $row_order_produk['nama_menu']; ?></h5>
											<b><?php echo $row_order_produk['jml']; ?> Menu </b> 
											x Rp. <?php echo $row_order_produk['harga']; ?>
											<p>
												<div class="view-edit">
												<a href="#ubah" data-toggle="modal" class="btn btn-warning btn-sm">
													<i class="fa fa-pencil-square-o" aria-hidden="true"></i> Ubah
												</a>
												</div>
											</p>
										</div>
									</div>
								</td>
								<td>
									<h5>Jumlah Harga</h5>
									<?php echo uang(perkalian($row_order_produk['jml'], $row_order_produk['harga'])); ?>
									<br>
									<br>
									<form method="POST">
										<button type="submit" name="hapus" value="y" class="btn btn-danger btn-sm pull-right">Hapus</button>
										<input type="hidden" name="kd_order_menu" value="<?php echo $row_order_produk['kd_order_menu']; ?>">
										<input type="hidden" name="kd_menu" value="<?php echo $row_order_produk['kd_menu']; ?>">
										<input type="hidden" name="jml" value="<?php echo $row_order_produk['jml']; ?>">
										<input type="hidden" name="kd_stok" value="<?php echo $row_stok['kd_stok']; ?>">
									</form>
								</td>
							</tr>

							<?php

							$jml_barang = $row_order_produk['jml']+$jml_barang;
							$sub_total = perkalian($row_order_produk['jml'], $row_order_produk['harga']) + $sub_total;
							}while($row_order_produk = $sql_order_produk->fetch()); ?>
							<tr>
								<!-- ============================================== Kolom Pengiriman -->
								
								<!-- ./ Kolom Pengiriman -->
								<td>
									<h5>Total Barang</h5>
									<p><?php echo $jml_barang; ?></p>
								</td>
								
								<td width="150px">
									<h5>Subtotal</h5>
									<p><?php echo uang($sub_total); ?></p>
								</td>
								
							</tr>

							<tr>
								
								<td align="center" colspan="2" style="font-size: 16px">
									Total Pembayaran <br><b style="color: red;"><?php echo uang($sub_total+$ongkir); ?></b>
								</td>
							</tr>
						</tbody>
					</table>
					
						
					


                	<?php else: ?>
						<p class="well text-center">
	                        Daftar Pesanan Kosong
	                    </p>
                	<?php endif; ?>
                </div>

            </div>
            <!-- /.row -->

        </div>
        <!-- /.container -->
		
		<div class="modal fade" id="ubah" role="dialog">
	        <div class="modal-dialog">
	            <div class="modal-content">
	                <div class="modal-body">
	                    <div id="hasil"></div>
	                </div>
	            </div>
	        </div>
	    </div>

	    <!-- 
		====================================================== Form Ubah Pengiriman -->
	    <div class="modal fade" id="ubah-alamat" role="dialog">
	        <div class="modal-dialog">
	            <div class="modal-content">
	                <div class="modal-body">
	                    <div>
						    <b style='font-size: 18px;'>Ubah Pelanggan</b>
						    <div style='float: right;'>
						        <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
						    </div>
						</div> <hr>

						<form method="POST">
							<div class="form-group" id="f-username">
                                <div class="input-group col-xs-12">
                                    <input type="text" class="form-control" id="nama_plg" name="nama_plg" placeholder="Nama Lengkap" autocomplete="off" required value="<?php echo $row_plg['nama_plg']; ?>">
                                    <span class="input-group-addon danger" style="display: none;"></span>
                                </div>
                            </div>
							<div class="form-group" id="f-username">
                                <div class="input-group col-xs-12">
                                    <textarea name="alamat_plg" class="form-control" required placeholder="Alamat"><?php echo $row_plg['alamat_plg']; ?></textarea>
                                    <span class="input-group-addon danger" style="display: none;"></span>
                                </div>
                            </div>
                            <div class="form-group" id="f-username">
                                <div class="input-group col-xs-12">
                                    <input type="text" class="form-control" maxlength="13" id="tlp_plg" name="tlp_plg" placeholder="Telepon" autocomplete="off" required autofocus onKeyPress="return goodchars(event,'0123456789',this)" value="<?php echo $row_plg['tlp_plg']; ?>">
                                    <span class="input-group-addon danger" style="display: none;"></span>
                                </div>
                            </div>
                            <div class="form-group" id="f-username">
                                <div class="input-group col-xs-12">
                                    <textarea name="email" class="form-control" required placeholder="Email"><?php echo $row_plg['email']; ?></textarea>
                                    <span class="input-group-addon danger" style="display: none;"></span>
                                </div>
                            </div>
						    <div class="row">
						    <div class="col-xs-6">
						    	<button name="edit_alamat" value="y" type="submit" class="btn btn-block btn-success">Simpan</button>
						    </div>
						    
						    </div>
						   
						</form>
	                </div>
	            </div>
	        </div>
	    </div>
	    </div>

        <?php include 'footer.php'; ?>

        <!-- Bootstrap core JavaScript
        ================================================== -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/validasi.js"></script>
        <script src="assets/js/validasiinput.js"></script>

        <script src="assets/js/jquery.bootstrap-touchspin.min.js"></script>
        <script>
        	$(document).ready(function(){
	          $(".view-edit").click(function(){
	            var id = $(this).parents('div').data('id');
	                $.ajax({
	                    type:"post",
	                    url:"ubah_daftar.php",
	                    data:"p="+ id,
	                    success: function(data){
	                      $("#hasil").html(data);
	                    }
	                });
	           });
	           $("#kurir").change(function(){
	           		document.fkurir.submit()
	           });
	           $("#pembayaran").change(function(){
	           		document.fpembayaran.submit()
	           });
	        });
		</script>
		<script>
            $(document).ready(function() {
             $('#kd_provinsi').change(function(){
                var id = $(this).val();
                $('#kd_kota').empty();
                    $.ajax({
                        type:"post",
                        url:"cari_kota.php",
                        data:"q="+ id,
                        success: function(data){
                          $("#kd_kota").html(data);
                            // if (data !== "") {
                            //     $('#kd_kota').prop('disabled', false);
                            // }else {
                            //     $('#kd_kota').prop('disabled', true);
                            // };
                        }
                    });
               });
           });
        </script>
    </body>
</html>