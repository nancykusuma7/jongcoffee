<?php 
include 'config.php';
include 'koneksi.php';
include 'assets/lib/function.php';
include 'query_header.php';

$q = $_GET['meja'];
$_SESSION['meja'] = $q;

$judul = "";

$sql_produk_home = $con->query("SELECT * FROM menu WHERE kategori='Makanan' ORDER BY kd_menu ASC");
$row_produk_home = $sql_produk_home->fetch(PDO::FETCH_LAZY);
$trow_produk_home = $sql_produk_home->rowCount();

$sql_produk_home1 = $con->query("SELECT * FROM menu WHERE kategori='Minuman' ORDER BY kd_menu ASC");
$row_produk_home1 = $sql_produk_home1->fetch(PDO::FETCH_LAZY);
$trow_produk_home1 = $sql_produk_home1->rowCount();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="shortcut icon" href="assets/images/icon.jpg" />
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/toko.css">
        <link rel="stylesheet" href="assets/fontawesome/css/font-awesome.min.css">
    </head>
    <body>
        <div class="container">

            <?php include 'header.php'; ?>


            <div class="row">             
    <div class="col-md-9"> 
      <div id="judul">Katalog Menu Makanan</div>
     
      <?php echo $judul; ?> 
      <div class="row"> 
        <?php do{ 
                                    if ($row_produk_home['diskon'] != null AND $row_produk_home['diskon'] != "0") {
                                        $ndskn = $row_produk_home['diskon'];
                                        $nilai_harga = uang($row_produk_home['harga']);
                                        $diskon = tampilDiskon($row_produk_home['diskon']);
                                        $hargaBarang = '<i style="text-decoration: line-through; color: #898989">'.$nilai_harga.'</i>';
                                        $hargaDiskon = uang(hargaDiskon($row_produk_home['diskon'],$row_produk_home['harga']));
                                    } else {
                                        $diskon = '';
                                        $hargaBarang = uang($row_produk_home['harga']);
                                        $hargaDiskon = "";
                                    }
                        ?>
        <a href="detail_menu?kd_menu=<?php echo $row_produk_home['kd_menu']; ?>"> 
        <div class="col-sm-3 col-lg-3 col-md-3"> 
          <div class="thumbnail"> 
            <div class="gproduk"> <?php if(isset($row_produk_home['kd_menu'])) { ?>
            	<img src="assets/images/menu/<?php echo $row_produk_home['foto']; ?>" width="100%"> 
             <?php } ?>
            </div>
            <div class="caption"> 
              <!-- <h4 class="pull-right">$24.99</h4> -->
              <p> <?php echo $row_produk_home['nama_menu']; ?> </p>
            </div>
            <div class="harga"> 
              <p class="text-right"> <?php echo $hargaBarang; ?> 
               
            </div>
          </div>
        </div>
        </a> 
        <?php }while($row_produk_home = $sql_produk_home->fetch()); ?>
      </div>
 	</div>
 	<?php include 'sidebar.php' ?>
      <div class="col-md-9"> 
      <div id="judul">Katalog Menu Minuman</div>
      
      <?php echo $judul; ?> 
      <div class="row"> 
        <?php do{ 
                                    if ($row_produk_home1['diskon'] != null AND $row_produk_home1['diskon'] != "0") {
                                        $ndskn = $row_produk_home1['diskon'];
                                        $nilai_harga = uang($row_produk_home1['harga']);
                                        $diskon = tampilDiskon($row_produk_home1['diskon']);
                                        $hargaBarang = '<i style="text-decoration: line-through; color: #898989">'.$nilai_harga.'</i>';
                                        $hargaDiskon = uang(hargaDiskon($row_produk_home1['diskon'],$row_produk_home1['harga']));
                                    } else {
                                        $diskon = '';
                                        $hargaBarang = uang($row_produk_home1['harga']);
                                        $hargaDiskon = "";
                                    }
                        ?>
        <a href="detail_menu?kd_menu=<?php echo $row_produk_home1['kd_menu']; ?>"> 
        <div class="col-sm-3 col-lg-3 col-md-3"> 
          <div class="thumbnail"> 
            <div class="gproduk"> <?php if(isset($row_produk_home1['kd_menu'])) { ?>
            	<img src="assets/images/menu/<?php echo $row_produk_home1['foto']; ?>" width="100%"> 
             <?php } ?> 
            </div>
            <div class="caption"> 
              <!-- <h4 class="pull-right">$24.99</h4> -->
              <p> <?php echo $row_produk_home1['nama_menu']; ?> </p>
            </div>
            <div class="harga"> 
              <p class="text-right"> <?php echo $hargaBarang; ?> 
               
            </div>
          </div>
        </div>
        </a> 
        <?php }while($row_produk_home1 = $sql_produk_home1->fetch()); ?>
      </div>
</div>


            </div>

        </div>
        <!-- /.container -->

        <?php include 'footer.php'; ?>

        <!-- Bootstrap core JavaScript
        ================================================== -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/validasi.js"></script>
        <script src="assets/js/validasiinput.js"></script>
    </body>
</html>