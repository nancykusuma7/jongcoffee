<?php
$meja = $_SESSION['meja'];
// Cek apakah pengguna sudah melakukan transaksi yang belum dikonfirmasi
$sql_status_faktur  = $con->query("SELECT * FROM pesanan WHERE meja='$meja' AND konfirm='Belum' ");
$row_status_faktur  = $sql_status_faktur->fetch(PDO::FETCH_LAZY);
$trow_status_faktur = $sql_status_faktur->rowCount();

// jika tidak ada
if (empty($trow_status_faktur)) {

    // dibuatkan kode faktur baru
	$_SESSION['kd_pesanan'] = time();
	$kd_pesanan             = $_SESSION['kd_pesanan'];

    // proses simpan ke tabel faktur
    $con->exec("INSERT INTO pesanan (kd_pesanan, meja) 
            VALUES (
            '".$kd_pesanan."',
            '".$meja."'
            )");

} else { // ada

    // kd faktur di ambil dari transaksi yang pernah dilakukan sebelumnya
	$_SESSION['kd_pesanan'] = $row_status_faktur['kd_pesanan'];
	$kd_pesanan             = $_SESSION['kd_pesanan'];
}
?>