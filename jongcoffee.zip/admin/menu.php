<?php
include '../koneksi.php';
include '../config.php';
include '../assets/lib/function.php';
$page = "menu";

if ((isset($_POST["fhapus"])) && ($_POST["fhapus"] == "y")) {

    $kd_menu  = $_POST['kd_menu'];
    $foto = $_POST['foto'];
    if ($foto != "menu.jpg") {
        unlink("../assets/images/menu/$foto");
    }
    $con->exec("DELETE FROM menu WHERE kd_menu = '$kd_menu'");
    $con->exec("DELETE FROM foto_menu WHERE kd_menu = '$kd_menu'");
    $con->exec("DELETE FROM stok WHERE kd_menu = '$kd_menu'");
    tampilPesan("Berhasil Dihapus!","Data yang dipilih berhasil dihapus!","success","$page");
}


$sql = $con->query("SELECT * FROM menu");
$row = $sql->fetch(PDO::FETCH_LAZY);
$trow = $sql->rowCount();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="shortcut icon" href="../assets/images/icon.jpg" />
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/animate.css">
        <link rel="stylesheet" href="../assets/css/admin.css">
        <link rel="stylesheet" href="../assets/fontawesome/css/font-awesome.min.css">
	    <link rel="stylesheet" href="../assets/css/datatables/dataTables.bootstrap.min.css">
	    <link rel="stylesheet" href="../assets/css/sweetalert.css">
    </head>
    <body class="skin-black">
    	<!-- memanggil file header -->
		<?php include 'header.php'; ?>

		<div class="wrapper row-offcanvas row-offcanvas-left">

			<!-- memanggil file sidemenu -->
			<?php include 'sidemenu.php'; ?>
			
			<aside class="right-side">
                <!-- Main content -->
				<section class="content">
				    <!-- Main row -->
				    <div class="row">
				        <div class="col-lg-12">
							<div class="panel">
				                <header class="panel-heading">
				                    menu
				                </header>
				                <div class="panel-body table-responsive">
				                	<!-- Tombol tambah -->
				                	<a href="print_menu" target="_blank" class="btn btn-primary btn-sm"><span class="fa fa-print"></span> Cetak</a>
				                	<a href="menu_tambah" class="btn btn-primary btn-sm"><span class="fa fa-plus"></span> Tambah</a>
				                	<br><br>

				                	<!-- Tabel -->
				                    <table id="tabel" class="table table-bordered table-striped" cellspacing="0" width="100%" style="font-size: 12px">
				                        <thead>
				                            <tr>
				                                <th>foto</th>
				                                <th>nama menu</th>
				                                <th>kategori</th>
				                                <th>Stok</th>
				                                <th>harga</th>
				                                <th>proses</th>
				                            </tr>
				                        </thead>
				                        <tbody>
				                        <?php do{ 
				                        	$kd_menu=$row['kd_menu']; 


				                        ?>
				                            <tr data-id="<?php echo $kd_menu; ?>">
				                                <td width="10%">
				                                	<img src="../assets/images/menu/<?php echo $row['foto']; ?>" class="img-thumbnail" width="100" height="100">
			                                	</td>
				                                <td><?php echo $row['nama_menu']; ?> </td>
				                                <td><?php echo $row['kategori']; ?> </td>
				                               
				                                <td width="20%">
				                                	
				                                	<?php
														$sql_stok = $con->query("SELECT * FROM stok WHERE kd_menu='$kd_menu' ");
														$row_stok = $sql_stok->fetch(PDO::FETCH_LAZY);
														$trow_stok = $sql_stok->rowCount();
														
															 echo stok($row_stok['stok']); 
					                                	
													?>
													
				                                </td>
				                                <td width="auto" align="right"><?php echo uang($row['harga']); ?></td>
				                                <td width="10%" align="center">
					                                <form method="POST" class="form-inline">
														<?php if(!empty($trow)): ?>
															<div class="view_detail" style="width: 100%; padding-bottom: 5px">
															<a href="#deskripsi" data-toggle="modal" class="btn btn-success btn-xs">Deskripsi</a>
															</div>

															<a href="menu_edit?kd_menu=<?php echo $kd_menu; ?>" class="btn btn-info btn-xs">Edit</a>
                                                    		<button type="submit" class='submit btn btn-danger btn-xs'>Hapus</button> 
														<?php endif; ?>
						                                <input type="hidden" name="fhapus" value="y" />
						                                <input type="hidden" name="kd_menu" value="<?php echo $row['kd_menu']; ?>" />
						                                <input type="hidden" name="foto" value="<?php echo $row['foto']; ?>" />
					                                </form>
				                                </td>
				                            </tr>
				                        <?php } while ($row = $sql->fetch(PDO::FETCH_LAZY)); ?>
				                        </tbody>
				                    </table>
				                </div>
				            </div>
						</div>
				  	</div> <!-- /.row -->
				</section><!-- /.content -->

            </aside><!-- /.right-side -->
		</div><!-- ./wrapper -->

		<div class="modal fade" id="deskripsi" role="dialog">
	        <div class="modal-dialog">
	            <div class="modal-content">
	                <div class="modal-body">
	                    <div id="hasil"></div>
	                </div>
	            </div>
	        </div>
	    </div>
        <!-- JavaScript
        ================================================== -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/app.js"></script>

        <!-- tabel -->
        <script src="../assets/js/datatables/jquery.dataTables.js"></script>
	    <script src="../assets/js/datatables/dataTables.bootstrap.min.js"></script>
	    <script>
	        $(document).ready(function(){
	          $(".view_detail").click(function(){
	            var id = $(this).parents('tr').data('id');
	                $.ajax({
	                    type:"post",
	                    url:"detail_menu.php",
	                    data:"q="+ id,
	                    success: function(data){
	                      $("#hasil").html(data);
	                    }
	                });
	           });
	        });
	    </script>
	    <script>
	        $(document).ready(function() {
	            $('#tabel').dataTable({
	                "columnDefs": [{
	                    "targets": [7],
	                    "searchable": false,
	                    "orderable": false,
	                    }]
	            });
	        });
	    </script>

	    

        <!-- konfirmasi -->
        <script src="../assets/js/sweetalert.js"></script>
		<script>
			$('.submit').on('click',function(e){
			    e.preventDefault();
			    var form = $(this).parents('form');
			    swal({
			        title: "Apakah anda yakin?",
			        text: "Data yang terhapus tidak dapat dikembalikan!",
			        type: "warning",
			        showCancelButton: true,
			        confirmButtonColor: "#DD6B55",
			        confirmButtonText: "Ya, hapus saja!",
			        cancelButtonText: "Batal",
			        closeOnConfirm: false
			    }, function(isConfirm){
			        if (isConfirm) form.submit();
			    });
			})
		</script>
    </body>
</html>