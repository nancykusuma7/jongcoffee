<aside class="left-side sidebar-offcanvas">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="../assets/images/foto/avatar.jpg" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
                <p>Hello, <?php echo $nama_akun; ?></p>

                <a href="javascript:void(0)"><i class="fa fa-calendar text-success" style="color: #fff"></i> <?php echo longDate(date("Y-m-d")); ?></a>
            </div>
        </div>
        <!-- search form -->
        <!-- <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search..."/>
                <span class="input-group-btn">
                    <button type='submit' name='seach' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
                </span>
            </div>
        </form> -->
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
            <li <?php menuAktif("index", $page); ?>>
                <a href="./">
                    <i class="fa fa-home fa-lg"></i> <span>Home</span>
                </a>
            </li>
            <li <?php menuAktif("meja", $page); ?>>
                <a href="meja">
                    <i class="fa fa-tags fa-lg"></i> <span>meja</span>
                </a>
            </li>
            <li <?php menuAktif("menu", $page); ?>>
                <a href="menu">
                    <i class="fa fa-archive fa-lg"></i> <span>menu</span>
                </a>
            </li>
            <!-- <li <?php// menuAktif("produk_custom", $page); ?>>
                <a href="produk_custom">
                    <i class="fa fa-archive fa-lg"></i> <span>produk Custom</span>
                </a>
            </li> -->
            <li <?php menuAktif("pelanggan", $page); ?>>
                <a href="pelanggan">
                    <i class="fa fa-users fa-lg"></i> <span>pelanggan</span>
                </a>
            </li>
            <li <?php menuAktif("pesanan", $page); ?>>
                <a href="pesanan">
                    <i class="fa fa-shopping-basket fa-lg"></i> <span>pesanan</span>
                </a>
            </li>
            

        </ul>
    </section>
    <!-- /.sidebar -->
</aside>