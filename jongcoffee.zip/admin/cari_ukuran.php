<?php  
include '../koneksi.php';

$q = $_POST['q'];
?>
<option>-- Pilih Ukuran --</option>
<?php
$sql_uk = $con->query("SELECT * FROM stok WHERE kd_produk='$q'");
$row_uk = $sql_uk->fetch();
do{
$ukuran = $row_uk['ukuran'];
?>
<option value="<?php echo $ukuran ?>">
<?php echo $ukuran; ?>
</option>
<?php }while($row_uk = $sql_uk->fetch()); ?>