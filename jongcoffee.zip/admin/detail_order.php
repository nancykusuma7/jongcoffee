<?php
include '../koneksi.php';
include '../config.php';
include '../assets/lib/function.php';
include '../assets/lib/rajaongkir.php';
$page = "order";


$kd_pesanan = $_GET['kd_pesanan'];
$id = $_GET['pelanggan'];
$sql_order_produk = $con->query("SELECT a.*, b.* FROM order_menu  as a, menu as b WHERE a.kd_pesanan='$kd_pesanan' AND b.kd_menu=a.kd_menu");
$row_order_produk = $sql_order_produk->fetch(PDO::FETCH_LAZY);
$trow_order_produk = $sql_order_produk->rowCount();

$sql_pelanggan = $con->query("SELECT * FROM pelanggan  ");
$row_pelanggan = $sql_pelanggan->fetch(PDO::FETCH_LAZY);
$trow_pelanggan = $sql_pelanggan->rowCount();

$jml_barang = 0;
$jml_berat = 0;
$sub_total = 0;

$sql_data_pesanan = $con->query("SELECT * FROM pesanan WHERE kd_pesanan='$kd_pesanan' ");
$row_data_pesanan = $sql_data_pesanan->fetch(PDO::FETCH_LAZY);
$trow_data_pesanan = $sql_data_pesanan->rowCount();
$userid = $row_data_pesanan['userid'];
$sql_plg = $con->query("SELECT * FROM pelanggan WHERE userid='$userid'");
$row_plg = $sql_plg->fetch(PDO::FETCH_LAZY);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="shortcut icon" href="../assets/images/icon.jpg" />
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/animate.css">
        <link rel="stylesheet" href="../assets/css/admin.css">
        <link rel="stylesheet" href="../assets/fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="../assets/css/datepicker/jquery-ui.css">
    </head>
    <body class="skin-black">
    	<!-- memanggil file header -->
		<?php include 'header.php'; ?>

		<div class="wrapper row-offcanvas row-offcanvas-left">

			<!-- memanggil file sidemenu -->
			<?php include 'sidemenu.php'; ?>
			
			<aside class="right-side">
                <!-- Main content -->
				<section class="content">
				    <!-- Main row -->
				    <div class="row">
				        <div class="col-lg-12">
							<div class="panel">
				                <header class="panel-heading">
				                    Detail Pesanan
				                </header>
				                <div class="panel-body">
				                	<!-- Tombol tambah -->
				                	<a href="print_pesanan_detail?kd_pesanan=<?php echo $kd_pesanan; ?>&&pelanggan=<?php echo $id ?>" target="_blank" class="btn btn-primary btn-sm"><span class="fa fa-print"></span> Cetak</a>
				                	<br><br>

				                	
				                	<!-- Tabel -->
				                    <table class="table table-bordered" style="font-size: 12px">
										<thead>
											<tr>
												<th colspan="5" style="text-align: left; font-weight: bold">
													<h5 style="font-weight: bold">No. pesanan: <?php echo $kd_pesanan; ?></h5>
													
													<h5>Tanggal : <?php echo longDate($row_data_pesanan['tgl']); ?></h5>
													<h5>Identitas Pelanggan : </h5>
									<div class="row" style="margin-bottom: 20px">
										<div class="col-xs-2">
											No. Meja:<br>
											Nama Pelanggan:<br>
											Alamat:<br>
											Telepon:<br>
											Email:<br>										
										</div>
										<div class="col-xs-3">
											<?php echo $row_data_pesanan['meja']; ?><br>
											<?php echo $row_plg['nama_plg']; ?><br>
											<?php echo $row_plg['alamat_plg']; ?><br>
											<?php echo $row_plg['tlp_plg']; ?><br>
											<?php echo $row_plg['userid']; ?><br>
										</div>
									</div>
												</th>
											</tr>
										</thead>
										<tbody>
											<?php do{ 
														
											?>
											<tr>
												<td >
													<div class="media">
														<div class="media-left">
															<div class="gproduk-sm">
																<img src="../assets/images/menu/<?php echo $row_order_produk['foto']; ?>" width="200" >
															</div>
														</div>
														<div class="media-body" data-id="<?php echo $row_order_produk['kd_menu']; ?>">
															<h5 class="media-heading"><?php echo $row_order_produk['nama_menu']; ?></h5>
															<b><?php echo $row_order_produk['jml']; ?> Barang 
															x <?php echo $row_order_produk['harga']; ?>
														</div>
													</div>
												</td>
												<td >
													<h5>Harga Barang</h5>
													<?php echo uang(perkalian($row_order_produk['jml'], $row_order_produk['harga'])); ?>
												</td>
											</tr>

											<?php

											$jml_barang = $row_order_produk['jml']+$jml_barang;
											$sub_total = perkalian($row_order_produk['jml'], $row_order_produk['harga']) + $sub_total;
											}while($row_order_produk = $sql_order_produk->fetch()); ?>
											<tr>
												<!-- ============================================== Kolom Pengiriman -->
											
												<!-- ./ Kolom Pengiriman -->
												<td>
													<h5>Total Barang</h5>
													<p><?php echo $jml_barang; ?></p>
												</td>
											
												<td width="150px">
													<h5>Subtotal</h5>
													<p><?php echo uang($sub_total); ?></p>
												</td>
											
											</tr>

											<tr>
												<td colspan="2" align="right" style="font-size: 16px">
													Total Pembayaran <b style="color: red;"><?php echo uang($sub_total); ?></b>
												</td>
											</tr>
											<tr>
												<td colspan="2" align="right" style="font-size: 16px">
													Bayar <b style="color: green;"><?php if($row_data_pesanan['bayar']==NULL) { echo "Rp. 0"; } else { echo uang($row_data_pesanan['bayar']); }  ?></b>
												</td>
											</tr>
											<tr>
												<td colspan="2" align="right" style="font-size: 16px">
													Kembalian <b style="color: orange;"><?php 
													$kembalian = $row_data_pesanan['bayar']-$sub_total;
													echo uang($kembalian);  ?></b>
												</td>
											</tr>
										</tbody>
									</table>
									
									
				                </div>
				            </div>
						</div>
				  	</div> <!-- /.row -->
				</section><!-- /.content -->

            </aside><!-- /.right-side -->
		</div><!-- ./wrapper -->

        <!-- JavaScript
        ================================================== -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/app.js"></script>
        <script src="../assets/js/validasi.js"></script>
	    <script src="../assets/js/validasiinput.js"></script>

        <script src="../assets/js/datepicker/jquery-ui.js"></script>
	    <script type="text/javascript">
	        $('#datepicker').datepicker({
	            dateFormat: "dd-mm-yy",
	            yearRange: '2000:2020',
	            changeMonth: true,
	            changeYear: true,
	            showAnim: "drop"
	        });
	    </script>
    </body>
</html>