<?php
include '../koneksi.php';
include '../akses.php';
include '../config.php';
include '../assets/lib/function.php';
include '../assets/lib/rajaongkir.php';
$page = "order";

$kd_pesanan = $_GET['kd_pesanan'];
$id = $_GET['pelanggan'];
$sql_order_produk = $con->query("SELECT a.*, b.* FROM order_menu  as a, menu as b WHERE a.kd_pesanan='$kd_pesanan' AND b.kd_menu=a.kd_menu");
$row_order_produk = $sql_order_produk->fetch(PDO::FETCH_LAZY);
$trow_order_produk = $sql_order_produk->rowCount();

$sql_pelanggan = $con->query("SELECT * FROM pelanggan  ");
$row_pelanggan = $sql_pelanggan->fetch(PDO::FETCH_LAZY);
$trow_pelanggan = $sql_pelanggan->rowCount();

$jml_barang = 0;
$jml_berat = 0;
$sub_total = 0;

$sql_data_pesanan = $con->query("SELECT * FROM pesanan WHERE kd_pesanan='$kd_pesanan' ");
$row_data_pesanan = $sql_data_pesanan->fetch(PDO::FETCH_LAZY);
$trow_data_pesanan = $sql_data_pesanan->rowCount();
$userid = $row_data_pesanan['userid'];
$sql_plg = $con->query("SELECT * FROM pelanggan WHERE userid='$userid'");
$row_plg = $sql_plg->fetch(PDO::FETCH_LAZY);



$userid = $_SESSION['userid'];
$sql_akun = $con->query("SELECT * FROM admin WHERE userid = '$userid' ");
$row_akun = $sql_akun->fetch(PDO::FETCH_LAZY);

$nama_akun = $row_akun['nama_admin'];


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/fontawesome/css/font-awesome.min.css">
    </head>
    <body onLoad="window.print()">
    	
    	
			
            <div class="col-md-3"> 
			<!-- Kop Laporan
			========================================================= -->
    		<header style="text-align: center">
    			<h3><?php echo $nama_perusahaan ?></h3>
    			<h3>Nota Penjualan Kopi</h3>
    			<hr style="border: 1px solid #000000">
    		</header>


    		<!-- Tabel
			========================================================= -->
            <table class="table table-bordered" style="font-size: 12px">
                <thead>
                    <tr>
                        <th colspan="2" style="text-align: left; font-weight: bold">
                            <h5 style="font-weight: bold">No. Pesanan: <?php echo $kd_pesanan; ?></h5>
                            
                            <h5>Tanggal : <?php echo longDate($row_data_pesanan['tgl']); ?></h5>
                            No. Meja : <?php echo $row_data_pesanan['meja']; ?><br>
                            Nama Pelanggan : <?php echo $row_plg['nama_plg']; ?><br>
                            Alamat : <?php echo $row_plg['alamat_plg']; ?><br>
                            Telepon : <?php echo $row_plg['tlp_plg']; ?><br>
                            Email : <?php echo $row_plg['userid']; ?><br>                                      
                                            
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php do{ 
                                
                    ?>
                    <tr>
                        <td>
                            <div class="media">
                                
                                <div class="media-body" data-id="<?php echo $row_order_produk['kd_menu']; ?>">
                                    <h5 class="media-heading"><?php echo $row_order_produk['nama_menu']; ?></h5>
                                    <b><?php echo $row_order_produk['jml']; ?> Barang  
                                    x <?php echo $row_order_produk['harga']; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            &nbsp<br>
                            <?php echo uang(perkalian($row_order_produk['jml'], $row_order_produk['harga'])); ?>
                        </td>
                    </tr>

                    <?php

                    $jml_barang = $row_order_produk['jml']+$jml_barang;
                   
                    $sub_total = perkalian($row_order_produk['jml'], $row_order_produk['harga']) + $sub_total;
                    }while($row_order_produk = $sql_order_produk->fetch()); ?>
                    <tr>
                         <td><b>TOTAL</b></td>
                        <td width="150px"><b><?php echo uang($sub_total); ?></b>
                    </tr>
                    <tr>
                         <td><b>BAYAR</b></td>
                        <td width="150px"><b><?php if($row_data_pesanan['bayar']==NULL) { echo "Rp. 0"; } else { echo uang($row_data_pesanan['bayar']); }  ?></b>
                    </tr>
                    <tr>
                         <td><b>KEKURANGAN</b></td>
                        <td width="150px"><b><?php 
                                                    $kembalian = $row_data_pesanan['bayar']-$sub_total;
                                                    echo uang($kembalian);  ?></b>
                    </tr>

                    
                </tbody>
            </table>
			
			<!-- Tanda Tangan
			========================================================= -->
            <div class="row" style="margin-top: 50px">
            	<div class="col-xs-8 pull-right" style="text-align: center">
            		<p>Mengetahui, <?php echo longDate(date("Y-m-d")); ?></p>
					<p>Kasir <?php echo $nama_perusahaan ?></p>
            	</div>
            </div>
            <div class="row" style="margin-top: 70px">
            	<div class="col-xs-8 pull-right" style="text-align: center">
            		<!-- ( ..................................... ) -->
                        ( <?php echo $nama_akun ?> )
            	</div>
            </div>
        </div>
    	</div>

        <!-- JavaScript
        ================================================== -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
    </body>
</html>