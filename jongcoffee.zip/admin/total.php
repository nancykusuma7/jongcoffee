<?php
$sql_torder = $con->query("SELECT * FROM pesanan ");
$row_torder = $sql_torder->fetch(PDO::FETCH_LAZY);
$trow_torder = $sql_torder->rowCount();

$sql_tplg = $con->query("SELECT * FROM pelanggan");
$row_tplg = $sql_tplg->fetch(PDO::FETCH_LAZY);
$trow_tplg = $sql_tplg->rowCount();

$sql_tbarang = $con->query("SELECT * FROM menu");
$row_tbarang = $sql_tbarang->fetch(PDO::FETCH_LAZY);
$trow_tbarang = $sql_tbarang->rowCount();

$sql_tmeja = $con->query("SELECT * FROM meja");
$row_tmeja = $sql_tmeja->fetch(PDO::FETCH_LAZY);
$trow_tmeja = $sql_tmeja->rowCount();
?>