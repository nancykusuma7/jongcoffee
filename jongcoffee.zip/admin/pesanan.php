<?php
include '../koneksi.php';
include '../config.php';
include '../assets/lib/function.php';
$page = "pesanan";

if ((isset($_POST["fhapus"])) && ($_POST["fhapus"] == "y")) {

    $kd_pesanan  = $_POST['kd_pesanan'];
    $con->exec("DELETE FROM pesanan WHERE kd_pesanan = '$kd_pesanan'");
    $con->exec("DELETE FROM order_menu WHERE kd_pesanan = '$kd_pesanan'");

    // pesan berhasil
    tampilPesan("Berhasil Dihapus!","Data yang dipilih berhasil dihapus!","success","$page");
}
if ((isset($_POST["fbayar"])) && ($_POST["fbayar"] == "y")) {

    $kd_pesanan  = $_POST['kd_pesanan'];
    $con->exec("UPDATE pesanan SET konfirm='Sudah' WHERE kd_pesanan = '$kd_pesanan'");
    $_SESSION['bayar']=="";
    // pesan berhasil
    tampilPesan("Berhasil dibayar!","Data yang dipilih berhasil dibayar!","success","$page");
}

if ((isset($_POST["fhapus2"])) && ($_POST["fhapus2"] == "y")) {

    $kd_pesanan  = $_POST['kd_pesanan'];
    $con->exec("DELETE FROM pesanan WHERE kd_pesanan = '$kd_pesanan'");
    $con->exec("DELETE FROM order_menu WHERE kd_pesanan = '$kd_pesanan'");

    // pesan berhasil
    tampilPesan("Berhasil Dihapus!","Data yang dipilih berhasil dihapus!","success","$page");
}

if ((isset($_POST["edit"])) && ($_POST["edit"] == "y")) {
	$bayar    = $_POST['bayar'];
	//$kd_stok     = $_POST['kd_stok'];
	//$stok_semula = $_POST['stok_semula'];
	$order       = $_POST['order'];
	//$faktur      = $_POST['faktur'];
	//$stok_baru   = $stok_semula-$jml_beli;

	$sql_pesan = $con->query("SELECT kd_pesanan, sum(jmlharga) as total FROM order_menu WHERE kd_pesanan='$order' ");
	$row_pesan = $sql_pesan->fetch(PDO::FETCH_LAZY);
	$trow_pesan = $sql_pesan->rowCount();

	$jmlharga = $row_pesan['total'];
	$status   = $bayar >= $jmlharga ? "Sudah" : "Belum";
	// $con->exec("UPDATE stok SET stok='$stok_semula' WHERE kd_stok='$kd_stok' ");
    $con->exec("UPDATE pesanan SET bayar='$bayar', konfirm='$status' WHERE kd_pesanan='$order'");
    // $con->exec("UPDATE stok SET stok=stok-$jml_beli WHERE kd_stok='$kd_stok' ");

	header("Location: pesanan");
}

// $sql = $con->query("SELECT a.*, b.* FROM pesanan as a, pelanggan as b WHERE b.email_plg=a.userid AND a.konfirm!='Belum' ORDER BY a.tgl DESC");
$sql = $con->query("SELECT a.*, b.* FROM pesanan as a, pelanggan as b WHERE b.userid=a.userid  ORDER BY a.tgl DESC");
$row = $sql->fetch(PDO::FETCH_LAZY);
$trow = $sql->rowCount();

$sql2 = $con->query("SELECT * FROM pesanan as a, pelanggan as b WHERE b.userid=a.userid ORDER BY a.tgl DESC");
$row2 = $sql2->fetch(PDO::FETCH_LAZY);
$trow2 = $sql2->rowCount();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="shortcut icon" href="../assets/images/icon.jpg" />
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/animate.css">
        <link rel="stylesheet" href="../assets/css/admin.css">
        <link rel="stylesheet" href="../assets/fontawesome/css/font-awesome.min.css">
	    <link rel="stylesheet" href="../assets/css/datatables/dataTables.bootstrap.min.css">
	    <link rel="stylesheet" href="../assets/css/sweetalert.css">
    </head>
    <body class="skin-black">
    	<!-- memanggil file header -->
		<?php include 'header.php'; ?>

		<div class="wrapper row-offcanvas row-offcanvas-left">

			<!-- memanggil file sidemenu -->
			<?php include 'sidemenu.php'; ?>
			
			<aside class="right-side">
                <!-- Main content -->
				<section class="content">
				    <!-- Main row -->
				    <div class="row">
				        <div class="col-lg-12">
							<div class="panel">
				                <header class="panel-heading">
				                    pesanan order
				                </header>
				                <div class="panel-body table-responsive">
				                	<!-- Tombol tambah -->
				                	<a href="lappesanan" class="btn btn-primary btn-sm"><span class="fa fa-print"></span> Cetak</a>
				                	<br><br>

				                	<!-- Tabel -->
				                    <table id="tabel" class="table table-bordered table-striped" cellspacing="0" width="100%" style="font-size: 12px">
				                        <thead>
				                            <tr>
				                                <th>KD. pesanan</th>
				                                <th>Pelanggan</th>
				                                <th>Total Biaya</th>
				                                <th>Tgl. Order</th>
				                                <th>Status</th>
				                                <th>proses</th>
				                            </tr>
				                        </thead>
				                        <tbody>
				                        <?php do{

				                        	$kd_pesanan=$row['kd_pesanan'];

				                        	if ($row['tgl_kirim'] == NULL) {
				                        		$tebal = "font-weight: bold";
				                        	} else {
				                        		$tebal = "font-weight: normal";
				                        	}
				                        	
				                        ?>
				                            <tr style="<?php echo $tebal; ?>">
				                                <td width="10%"><?php echo $row['kd_pesanan']; ?></td>
				                                <td width="15%"><?php echo $row['nama_plg']; ?></td>
				                                <td width="15%"><?php 
			                                $sqlbayar = $con->query("SELECT sum(jmlharga) as totharga FROM order_menu WHERE kd_pesanan='$kd_pesanan'");
											$rowbayar = $sqlbayar->fetch(PDO::FETCH_LAZY);
			                                echo uang($rowbayar['totharga']); ?></td>
				                                <td width="15%"><?php echo longDateTs($row['tgl']); ?></td>
				                                <td width="10%"><?php if ($row['konfirm'] != 'Sudah'): ?>
				                                <div class="media-body" data-id="<?php echo $row['kd_pesanan'];?>">
	                                                    		<div class="view-edit">
												<a href="#ubah" data-toggle="modal" class="btn btn-success btn-sm">
													<i class="fa fa-pencil-square-o" aria-hidden="true"></i> Bayar
												</a>
												</div>
															<?php else: echo "SELESAI"; endif ?><input type="hidden" name="fbayar" value="y" />
						                                
					                               </td>
				                                <td width="10%">
					                                <form method="POST">
														<?php if(!empty($trow)): ?>
															<a href="detail_order?kd_pesanan=<?php echo $kd_pesanan; ?>&&pelanggan=<?php echo $row['userid'] ?>" class="btn btn-info btn-xs">Detail</a>
															<?php if ($row['konfirm'] != 'Sudah'): ?>
	                                                    		<button type="submit" class='submit btn btn-danger btn-xs'>Hapus</button> 
															<?php endif ?>
														<?php endif; ?>
						                                <input type="hidden" name="fhapus" value="y" />
						                                <input type="hidden" name="kd_pesanan" value="<?php echo $row['kd_pesanan']; ?>" />
					                                </form>
				                                </td>
				                            </tr>
				                        <?php } while ($row = $sql->fetch(PDO::FETCH_LAZY)); ?>
				                        </tbody>
				                    </table>
				                </div>
				            </div>
						</div>


<div class="modal fade" id="ubah" role="dialog">
	        <div class="modal-dialog">
	            <div class="modal-content">
	                <div class="modal-body">
	                    <div id="hasil"></div>
	                </div>
	            </div>
	        </div>
	    </div>
						

				  	</div> <!-- /.row -->
				</section><!-- /.content -->

            </aside><!-- /.right-side -->
		</div><!-- ./wrapper -->

        <!-- JavaScript
        ================================================== -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/app.js"></script>

        <!-- tabel -->
        <script src="../assets/js/datatables/jquery.dataTables.js"></script>
	    <script src="../assets/js/datatables/dataTables.bootstrap.min.js"></script>
	
      <script>
            $(document).ready(function() {
             
                $(document).on("keyup", "#keybayar", function(){
                    var id = $(this).val();
                    var jmlhrg = $('#jmlharga').val();

		            var val = parseInt($(this).val()) + parseInt($("body").find("#kekurangan").val());
		            $("#bayar").val(val);

                    if(id.length > 0) $("#tbbayar").removeAttr('disabled');
                    else $("#tbbayar").attr('disabled', true);

                    /*if(id >= jmlhrg)
                    { 
                        $("#tbbayar").removeAttr('disabled');
                    }
                    else
                    {
                    	$("#tbbayar").attr('disabled', true)
                    }*/
               });
           });
</script>
	    <script>
        	$(document).ready(function(){
	          $(".view-edit").click(function(){
	            var id = $(this).parents('div').data('id');
	                $.ajax({
	                    type:"post",
	                    url:"bayar.php",
	                    data:"p="+ id,
	                    success: function(data){
	                      $("#hasil").html(data);
	                    }
	                });
	           });
	          });
		</script>
	    <script>
	        $(document).ready(function() {
	            $('#tabel').dataTable({
	                "columnDefs": [{
	                    "targets": [7],
	                    "searchable": false,
	                    "orderable": false,
	                    }],
	                "order": false
	            });
	            $('#tabel2').dataTable({
	                "columnDefs": [{
	                    "targets": [7],
	                    "searchable": false,
	                    "orderable": false,
	                    }],
	                "order": false
	            });
	        });
	    </script>

        <!-- konfirmasi -->
        <script src="../assets/js/sweetalert.js"></script>
		<script>
			$('.submit').on('click',function(e){
			    e.preventDefault();
			    var form = $(this).parents('form');
			    swal({
			        title: "Apakah anda yakin?",
			        text: "Data yang terhapus tidak dapat dikembalikan!",
			        type: "warning",
			        showCancelButton: true,
			        confirmButtonColor: "#DD6B55",
			        confirmButtonText: "Ya, hapus saja!",
			        cancelButtonText: "Batal",
			        closeOnConfirm: false
			    }, function(isConfirm){
			        if (isConfirm) form.submit();
			    });
			});

			$('.submit3').on('click',function(e){
			    e.preventDefault();
			    var form = $(this).parents('form');
			    swal({
			        title: "Apakah anda yakin?",
			        text: "Melakukan Pembayaran!",
			        type: "warning",
			        showCancelButton: true,
			        confirmButtonColor: "#DD6B55",
			        confirmButtonText: "Ya, Bayar!",
			        cancelButtonText: "Batal",
			        closeOnConfirm: false
			    }, function(isConfirm){
			        if (isConfirm) form.submit();
			    });
			})
			$('.submit2').on('click',function(e){
			    e.preventDefault();
			    var form = $(this).parents('form');
			    swal({
			        title: "Apakah anda yakin?",
			        text: "Data yang terhapus tidak dapat dikembalikan!",
			        type: "warning",
			        showCancelButton: true,
			        confirmButtonColor: "#DD6B55",
			        confirmButtonText: "Ya, hapus saja!",
			        cancelButtonText: "Batal",
			        closeOnConfirm: false
			    }, function(isConfirm){
			        if (isConfirm) form.submit();
			    });
			})
		</script>
    </body>
</html>