<?php
include '../koneksi.php';
include '../config.php';
include '../assets/lib/function.php';


$sql = $con->query("SELECT * FROM menu");
$row = $sql->fetch(PDO::FETCH_LAZY);
$trow = $sql->rowCount();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="shortcut icon" href="../assets/images/icon.jpg" />
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/fontawesome/css/font-awesome.min.css">
    </head>
    <body onLoad="window.print()">
    	
    	<div class="container">
			

			<!-- Kop Laporan
			========================================================= -->
    		<header style="text-align: center">
    			<h3>Laporan menu <?php echo $nama_perusahaan ?></h3>
    			<hr style="border: 1px solid #000000">
    		</header>


    		<!-- Tabel
			========================================================= -->
            <table id="tabel" class="table table-bordered" cellspacing="0" width="100%" style="font-size: 12px">
                <thead>
                    <tr>
                        <th>foto</th>
                        <th>nama menu</th>
                        <th>kategori</th>
                        <th>harga</th>
                        <th>Stok</th>
                        <th>deskripsi</th>
                    </tr>
                </thead>
                <tbody>
                <?php do{ 
                    $kd_menu=$row['kd_menu']; 

                ?>
                    <tr data-id="<?php echo $kd_menu; ?>">
                        <td width="10%">
                            <img src="../assets/images/menu/<?php echo $row['foto']; ?>" class="img-thumbnail" width="100" height="100">
                        </td>
                        <td><?php echo $row['nama_menu']; ?></td>
                        <td><?php echo $row['kategori']; ?></td>
                        <td><?php echo uang($row['harga']); ?></td>
                        
                        <td width="20%">
                                                    <div class="row">
                                                    <?php
                                                        $sql_stok = $con->query("SELECT * FROM stok WHERE kd_menu='$kd_menu' ");
                                                        $row_stok = $sql_stok->fetch(PDO::FETCH_LAZY);
                                                        $trow_stok = $sql_stok->rowCount();
                                                        do {
                                                    ?>
                                                        <div class="col-sm-5">
                                                            <?php echo stok($row_stok['stok']); ?>
                                                        </div>
                                                    <?php
                                                        } while ($row_stok = $sql_stok->fetch(PDO::FETCH_LAZY));
                                                    ?>
                                                    </div>
                                                </td>
                        <td width="auto"><?php echo $row['deskripsi']; ?></td>
                        
                    </tr>
                <?php } while ($row = $sql->fetch(PDO::FETCH_LAZY)); ?>
                </tbody>
            </table>
			
			<!-- Tanda Tangan
			========================================================= -->
            <div class="row" style="margin-top: 50px">
            	<div class="col-xs-4 pull-right" style="text-align: center">
            		<p>Mengetahui, <?php echo longDate(date("Y-m-d")); ?></p>
					<p>Manager <?php echo $nama_perusahaan ?></p>
            	</div>
            </div>
            <div class="row" style="margin-top: 70px">
            	
    <div class="col-xs-4 pull-right" style="text-align: center"><strong>( ................................................... ) </strong></div>
            </div>
    	</div>

        <!-- JavaScript
        ================================================== -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
    </body>
</html>