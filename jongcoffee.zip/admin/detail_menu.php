<?php 
include '../koneksi.php';

$kd_menu = $_POST['q'];

$sql = $con->query("SELECT * FROM menu WHERE kd_menu='$kd_menu'");
$row = $sql->fetch();
$noUrut = 1;

?>

<div>
    <b style='font-size: 18px;'>Deskripsi Menu</b>
    <div style='float: right;'>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
    </div>
</div> <hr>
<?php
echo $row['deskripsi'];
?>
