<?php
include '../koneksi.php';
include '../config.php';
include '../assets/lib/function.php';
$page = "menu";
$tbbatal = "Batal";
$gagal = false;
if ((isset($_POST["ftambah"])) && ($_POST["ftambah"] == "y")) {

	$kd_menu   = $_POST['kd_menu'];
	$nama_menu = $_POST['nama_menu'];
	$kategori = $_POST['kategori'];
	
	$harga       = hanyaAngka($_POST['harga']);
	$stok   	 = $_POST['stok'];
	$deskripsi   = $_POST['deskripsi'];
	$foto        = $_FILES['foto']['name'];
	$nama_unik   = $_POST['nama_unik'];
	$jumlah_foto = count($_FILES['foto']['name']);
	// $isi      = $_POST['promo'];

	    // query untuk mencari nama menu yang sama
    $sql_cek = $con->query("SELECT * FROM menu WHERE nama_menu='$nama_menu' AND kd_menu!='$kd_menu' ");
    $row_cek = $sql_cek->fetch(PDO::FETCH_LAZY);
    $trow_cek = $sql_cek->rowCount();

    if (empty($trow_cek)) { // bila data tidak ada

    	// ======================= Input Stok dan ukuran
    	$con->exec("UPDATE stok SET stok='$stok' WHERE kd_menu='$kd_menu' ");

    	if (!empty($foto)) {  // jika foto tidak kosong
    		
			$folder     = '../assets/images/menu/';
        	$no = 1;

        	for ($i=0; $i < $jumlah_foto; $i++) { 

            	$foto_baru = "menu".$nama_unik.$no++."sc.jpeg";
            	if (move_uploaded_file($_FILES['foto']['tmp_name'][$i], $folder.$foto_baru)) {
				
				//identitas file asli
				$im_src = imagecreatefromjpeg($folder.$foto_baru);
				$src_width = imageSX($im_src);
				$src_height = imageSY($im_src);

				//Simpan dalam versi small 110 pixel
				//set ukuran gambar hasil perubahan
				$dst_width = 300;
				$dst_height = ($dst_width/$src_width)*$src_height;

				//proses perubahan ukuran
				$im = imagecreatetruecolor($dst_width,$dst_height);
				imagecopyresampled($im, $im_src, 0, 0, 0, 0, $dst_width, $dst_height, $src_width, $src_height);

				//Simpan gambar
				$foto_baru2 = "tb_".$foto_baru;
				imagejpeg($im,$folder.$foto_baru2);
				//Hapus gambar di memori komputer
			   imagedestroy($im_src);
			   imagedestroy($im);

            		$con->exec("INSERT INTO foto_menu (kd_menu, foto) 
				    			VALUES (
				    			'".$kd_menu."',
				    			'".$foto_baru."'
				    			)");
            	} else {
            		// pesan gagal
				    tampilPesan("Gagal Disimpan!","Telah terjadi kesalahan pada sistem!","warning");
				    $tbbatal = "Ulangi";
            	}
        	}
        	$sql_pfoto = $con->query("SELECT * FROM foto_menu WHERE kd_menu='$kd_menu' ");
        	$row_pfoto = $sql_pfoto->fetch(PDO::FETCH_LAZY);
        	$trow_pfoto = $sql_pfoto->rowCount();
        	if (!empty($trow_pfoto)) {
        		$pfoto = $row_pfoto['foto'];
        	} else {
        		$pfoto = "menu.jpg";
        	}
        	$con->exec("UPDATE menu SET nama_menu='$nama_menu', kategori='$kategori', harga='$harga', deskripsi='$deskripsi', foto='$pfoto' WHERE kd_menu='$kd_menu' ");

        	tampilPesan("Berhasil Disimpan!","Data yang anda inputkan berhasil disimpan!","success","menu");
            

    	} else { // foto kosong
	    	// proses simpan tanpa upload gambar
		    $con->exec("UPDATE menu SET nama_menu='$nama_menu', kategori='$kategori', harga='$harga', deskripsi='$deskripsi' WHERE kd_menu='$kd_menu' ");
		    // pesan berhasil
		    tampilPesan("Berhasil Disimpan!","Data yang anda inputkan berhasil disimpan!","success","menu");
    	}
    	

    } else { // bila data ada
	    // pesan gagal
	    tampilPesan("Gagal Disimpan!","Data yang anda inputkan sudah ada!","warning");
	    $tbbatal = "Ulangi";
    } //end if

}

if ((isset($_GET["hapusfoto"])) && ($_GET["hapusfoto"] == "y")) {

    $kd_menu  = $_GET['kd_menu'];
    $foto = $_GET['foto'];
    if ($foto != "menu.jpg") {
        unlink("../assets/images/menu/$foto");
        unlink("../assets/images/menu/tb_$foto");
    }
    $con->exec("DELETE FROM foto_menu WHERE foto = '$foto'");
    tampilPesan("Berhasil Dihapus!","Data yang dipilih berhasil dihapus!","success","menu_edit?kd_menu=$kd_menu");
}

$kd_menu = $_GET['kd_menu'];
$sql = $con->query("SELECT menu.*, stok.* FROM menu, stok WHERE stok.kd_menu=menu.kd_menu AND menu.kd_menu='$kd_menu' ");
$row = $sql->fetch(PDO::FETCH_LAZY);

$sql_foto = $con->query("SELECT * FROM foto_menu WHERE kd_menu='$kd_menu' ");
$row_foto = $sql_foto->fetch(PDO::FETCH_LAZY);
$trow_foto = $sql_foto->rowCount();

$sql_stok = $con->query("SELECT * FROM stok WHERE kd_menu='$kd_menu'");
$row_stok = $sql_stok->fetch(PDO::FETCH_LAZY);
$trow_stok = $sql_stok->rowCount();
$tdk = $row_stok['kd_stok'];

$sql_stok2 = $con->query("SELECT * FROM stok WHERE kd_menu='$kd_menu' AND kd_stok!='$tdk' ");
$trow_stok2 = $sql_stok2->rowCount();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="shortcut icon" href="../assets/images/icon.jpg" />
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/animate.css">
        <link rel="stylesheet" href="../assets/css/admin.css">
        <link rel="stylesheet" href="../assets/fontawesome/css/font-awesome.min.css">
	    <link rel="stylesheet" href="../assets/css/sweetalert.css">
	    <link rel="stylesheet" href="../assets/css/fileinput.css">
    </head>
    <body class="skin-black">
    	<!-- memanggil file header -->
		<?php include 'header.php'; ?>

		<div class="wrapper row-offcanvas row-offcanvas-left">

			<!-- memanggil file sidemenu -->
			<?php include 'sidemenu.php'; ?>
			
			<aside class="right-side">
                <!-- Main content -->
				<section class="content">
				    <!-- Main row -->
				    <div class="row">
				        <div class="col-lg-12">
							<div class="panel">
				                <header class="panel-heading">
				                    Edit menu
				                </header>
				                <div class="panel-body table-responsive">
				                <?php if (!empty($trow_foto)): ?>
				                <div class="row">
								<?php do{ ?>
									<form method="GET">
									<div class="col-sm-3">
										<div class="thumbnail">
											<div class="gmenu">
												<img src="../assets/images/menu/<?php echo $row_foto['foto']; ?>" >
											</div>
											<div class="caption">
												<p>
													<button type="submit" class="btn btn-danger" >Hapus</button>
												</p>
											</div>
										</div>
									</div>
									<input type="hidden" name="hapusfoto" value="y">
									<input type="hidden" name="foto" value="<?php echo $row_foto['foto']; ?>">
									<input type="hidden" name="kd_menu" value="<?php echo $kd_menu; ?>">
									</form>
								<?php }while($row_foto = $sql_foto->fetch()); ?>
								</div>
				                <?php endif ?>
                                <form method="POST" enctype="multipart/form-data">
				                	<div class="row">
			                            <div class="col-xs-12">
			                            	<div class="row">
					                            <div class="col-xs-12">
				                            		<div class="form-group">
					                            		<label>Gambar</label>
					                            		<div class="input-group col-xs-12">
				                                            <input id="avatar" name="foto[]" type="file"  multiple class="file" data-overwrite-initial="false" />
			                                            </div>
			                                        </div>
			                                    </div>
			                                    <div class="col-xs-3">
				                                    <div class="form-group">
				                                        <label>Nama menu</label>
				                                        <div class="input-group col-xs-12">
				                                            <input type="text" class="form-control" name="nama_menu" required autocomplete="off" value="<?php echo $row['nama_menu']; ?>">
				                                            <span class="input-group-addon danger" style="display: none;"></span>
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="col-xs-3">
				                                    <div class="form-group">
				                                        <label>Kategori</label>
				                                        <div class="input-group col-xs-12">
															<select name="kategori" class="form-control" required>
																<option>-- Pilih Kategori --</option>
																<option <?php echo terpilih("Makanan",$row['kategori']); ?>>Makanan</option>
																<option <?php echo terpilih("Minuman",$row['kategori']); ?>>Minuman</option>
															</select>
				                                            <span class="input-group-addon danger" style="display: none;"></span>
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="col-xs-4">
				                                	<div class="form-group">
				                                        <label>Harga</label>
				                                        <div class="input-group col-xs-12">
				                                            <input id="harga" type="text" class="form-control" name="harga" required autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)" value="<?php echo $row['harga']; ?>">
				                                            <span class="input-group-addon danger" style="display: none;"></span>
				                                        </div>
				                                    </div>
				                                </div>
				                                
													<div class="col-xs-5">
														<div class="form-group">
															<label>Stok</label>
															<div class="input-group col-xs-12">
																<input type="text" class="form-control" name="stok" maxlength="5" required autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)" value="<?php echo $row['stok']; ?>">
																<span class="input-group-addon danger" style="display: none;"></span>
															</div>
														</div>
													</div>
													
				                            <div class="row">
				                            	<div class="col-xs-12">
				                                    <div class="form-group">
				                                        <label>Deskripsi</label>
				                                        <div class="input-group col-xs-12">
				                                        <textarea name="deskripsi" class="ckeditor" id="editor1"><?php echo $row['deskripsi']; ?></textarea>
				                                        </div>
				                                    </div>
				                                    <button type="submit" class="btn btn-success">Simpan</button>
				                                    <button type="button" class="btn btn-danger" onclick="self.history.back()"><?php echo $tbbatal; ?></button>
				                                    <input type="hidden" name="ftambah" value="y" />
				                                    <input type="hidden" name="kd_menu" value="<?php echo $kd_menu; ?>" />
				                                    <input type="hidden" name="foto_lama" value="<?php echo $foto; ?>" />
				                                    <input type="hidden" name="nama_unik" value="<?php echo date("dmyhis"); ?>" />
				                                    <input id="idf" value="<?php echo $trow_stok+1; ?>" type="hidden" />
				                                </div>
				                            </div>
			                            </div>
			                        </div><!-- /.row -->
				                </div> <!-- /.panel body -->
	                            </form>
				            </div> <!-- /.panel -->
						</div>
				  	</div> <!-- /.row -->
				</section> <!-- /.content -->

            </aside><!-- /.right-side -->
		</div><!-- ./wrapper -->

        <!-- JavaScript
        ================================================== -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/app.js"></script>
        <script src="../assets/js/sweetalert.js"></script>
	    <script src="../assets/js/validasi.js"></script>
	    <script src="../assets/js/validasiinput.js"></script>
	    <script src="../assets/js/matauang.js"></script>
	    <script type="text/javascript">
		    $('#harga').priceFormat({ 
		      prefix: '', // Simbol mata uang
		      centsSeparator: '.', // Karakter pemisah untuk sen atau koma, gunakan str_replace saat menyimpan data ke database
		      thousandsSeparator: '.', // Karakter pemisah untuk ribuan
		      centsLimit: 0 // Jumlah batas angka di belakang koma
		    });
	    </script>

	    <script src="../assets/js/ckeditor/ckeditor.js"></script>
        <script language="javascript" type="text/javascript">
            CKEDITOR.replace( 'editor1',
            {
            	toolbar : 'Basic',
                height: '300px',
                // filebrowserWindowWidth : '900',
                // filebrowserWindowHeight : '400',
                filebrowserBrowseUrl : '/khanza/assets/js/ckfinder/ckfinder.html',
                filebrowserImageBrowseUrl : '/khanza/assets/js/ckfinder/ckfinder.html?type=Images',
                filebrowserFlashBrowseUrl : '/khanza/assets/js/ckfinder/ckfinder.html?type=Flash',
                filebrowserUploadUrl : '/khanza/assets/js/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                filebrowserImageUploadUrl : '/khanza/assets/js/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
                filebrowserFlashUploadUrl : '/khanza/assets/js/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash',
            });
        </script>

        <script src="../assets/js/file-input/fileinput.js" type="text/javascript"></script>
        <script src="../assets/js/file-input/fileinput_locale_LANG.js" type="text/javascript"></script>
        <script>
        $("#avatar").fileinput({
			uploadUrl: 'http://web/khanza/assets/images/menu/', // you must set a valid URL here else you will get an error
			overwriteInitial: false,
			maxFileSize: 1000000,
			maxFilesNum: 10,
			showUpload: false,
			layoutTemplates: {main2: '{preview} {browse}'},
			allowedFileExtensions: ["jpg"],
			slugCallback: function(filename) {
			return filename.replace('(', '_').replace(']', '_');
			}
        });
        </script>

        <script language="javascript">
		   function tambahStok() {
		     var idf = document.getElementById("idf").value;
		     var stre;
		     stre="<div id='srow"+idf+"'><div class=\"col-xs-5\"><div class=\"form-group\"><label>Ukuran</label><div class=\"input-group col-xs-12\"><input type=\"text\" class=\"form-control\" name=\"ukuran[]\" required autocomplete=\"off\"  value=\"\"><span class=\"input-group-addon danger\" style=\"display: none;\"></span></div></div></div><div class=\"col-xs-5\"><div class=\"form-group\"><label>Stok</label><div class=\"input-group col-xs-12\"><input type=\"text\" class=\"form-control\" name=\"stok[]\" maxlength=\"5\" required autocomplete=\"off\" onKeyPress=\"return goodchars(event,\'0123456789\',this)\" value=\"\"><span class=\"input-group-addon danger\" style=\"display: none;\"></span></div></div></div><div class=\"col-xs-2\"><div class=\"form-group\"><label>&nbsp</label><div class=\"input-group col-xs-12\"><a class=\"btn btn-danger\" href=\"#\" onclick='hapusElemen(\"#srow"+idf+"\"); return false;'>Hapus</a></div></div></div></div>";
		     $("#input").append(stre);
		     idf = (idf-1) + 2;
		     document.getElementById("idf").value = idf;
		   }
		   function hapusElemen(idf) {
		     $(idf).remove();
		   }
		</script>
    </body>
</html>