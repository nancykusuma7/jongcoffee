
<?php 
include '../koneksi.php';
include '../assets/lib/function.php';
$p             = $_POST['p'];
$potongan_data = explode("/", $p); 
$kd_pesanan     = $potongan_data[0];


$sql_pesan = $con->query("SELECT kd_pesanan, sum(jmlharga) as total FROM order_menu WHERE kd_pesanan='$kd_pesanan' ");
$row_pesan = $sql_pesan->fetch(PDO::FETCH_LAZY);
$trow_pesan = $sql_pesan->rowCount();

$sql_kem = $con->query("SELECT kd_pesanan, bayar FROM pesanan WHERE kd_pesanan='$kd_pesanan' ");
$row_kem = $sql_kem->fetch(PDO::FETCH_LAZY);
$trow_kem = $sql_pesan->rowCount();

$jmlharga = $row_pesan['total'];
$kembalian= ($row_kem['bayar']) != 0 ? $row_kem['bayar'] - $row_pesan['total'] : 0;
?>

<div>
    <b style='font-size: 18px;'>Bayar Pesanan</b>
    <div style='float: right;'>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
    </div>
</div> <hr>
<?php echo "Status : ".$_SESSION['bayar']; ?>
<form method="POST">	<div class="form-group">
        <label>Kode Pesanan</label>
        <div class="input-group col-xs-12">
            <input class="form-control" value="<?php echo $row_pesan['kd_pesanan']; ?>" readonly>
            <span class="input-group-addon danger" style="display: none;"></span>
        </div>
    </div>
	<div class="form-group">
        <label>Jumlah Pembayaran</label>
        <div class="input-group col-xs-3">
            <input class="form-control" value="<?php echo uang($jmlharga); ?>" readonly> 
            <input id="jmlharga" class="form-control" value="<?php echo $jmlharga; ?>" readonly style="display:none"> 

        </div>

    </div>
    <div class="form-group">
        <label>Jumlah Kekurangan</label>
        <div class="input-group col-xs-3">
            <input class="form-control" value="<?php echo uang($kembalian); ?>" readonly> 
            <input id="kekurangan" value="<?= $row_kem["bayar"] ?>" style="display:none">
        </div>

    </div>
    <div class="form-group">
        <label>Bayar</label>
        <div class="input-group col-xs-3">
            <input id="keybayar" type="text" name="keybayar" class="form-control" autofocus>

            <input id="bayar" type="text" name="bayar" class="form-control" style="display:none">
        </div>
    </div>
    <?php if(empty($_SESSION['bayar'])) { ?>
    <button id="tbbayar" name="edit" value="y" type="submit" class="btn btn-block btn-success" disabled>Bayar</button>    
<?php } else { ?>
    <button id="tbbayar" name="edit" value="y" type="submit" class="btn btn-block btn-success">Bayar</button>
<?php } ?>
    
    <input type="hidden" name="pesanan" value="<?php echo $f; ?>">
    <input type="hidden" name="order" value="<?php echo $row_pesan['kd_pesanan']; ?>">
    
</form>