<?php
include('../koneksi.php');

$kd_produk = $_GET['kd_produk'];
$sql     = $con->query("SELECT * FROM produk WHERE kd_produk='$kd_produk'");
$row     = $sql->fetch();
$trow    = $sql->rowCount();

if (empty($trow)) {
    $hargabeli  = 0;
} else {
	$hargabeli  = $row['hargabeli'];
}

$output = array(
    'hargabeli' =>$hargabeli,
);

echo json_encode($output);
?>