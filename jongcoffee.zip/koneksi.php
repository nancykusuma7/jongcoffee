<?php
error_reporting(1);
$hostname = 'localhost';
$username = 'root';
$password = '';
$database= 'db_kopi';
$con = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
if (!isset($_SESSION)) {
  session_start();
}
?>