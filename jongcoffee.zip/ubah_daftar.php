<?php 
include 'koneksi.php';

$p             = $_POST['p'];
$potongan_data = explode("/", $p); 
$kd_menu     = $potongan_data[0];
$f             = $_SESSION['kd_pesanan'];
$meja             = $_SESSION['meja'];

$sql_produk = $con->query("SELECT * FROM menu WHERE kd_menu='$kd_menu' ");
$row_produk = $sql_produk->fetch(PDO::FETCH_LAZY);
$trow_produk = $sql_produk->rowCount();

$sql_order = $con->query("SELECT * FROM order_menu WHERE kd_pesanan='$f' AND kd_menu='$kd_menu' AND meja='$meja' ");
$row_order = $sql_order->fetch(PDO::FETCH_LAZY);
$trow_order = $sql_order->rowCount();

?>

<div>
    <b style='font-size: 18px;'>Ubah Daftar Pesanan</b>
    <div style='float: right;'>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
    </div>
</div> <hr>

<form method="POST">
	<div class="form-group">
        <label>Nama Menu</label>
        <div class="input-group col-xs-12">
            <input class="form-control" value="<?php echo $row_produk['nama_menu']; ?>" readonly>
            <span class="input-group-addon danger" style="display: none;"></span>
        </div>
    </div>
	<div class="form-group">
        <label>Jumlah Pesan</label>
        <div class="input-group col-xs-3">
            <input id="jml" type="text" readonly name="jml" value="<?php echo $row_order['jml']; ?>" class="text-center">

        </div>
    </div>

    <button name="edit" value="y" type="submit" class="btn btn-block btn-success">Simpan</button>
    <input type="hidden" name="pesanan" value="<?php echo $f; ?>">
    <input type="hidden" name="order" value="<?php echo $row_order['kd_order_menu']; ?>">
    <input type="hidden" name="harga" value="<?php echo $row_produk['harga']; ?>">
</form>
<script>

    $("#jml").TouchSpin({
    	min: 1,
    	buttondown_class: 'btn btn-default',
    	buttonup_class: 'btn btn-default'
    });
</script>