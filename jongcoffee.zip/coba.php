<?php

$_nama = "Vita";
echo $_nama;



?>