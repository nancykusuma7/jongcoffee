<?php
date_default_timezone_set('Asia/Jakarta');
$title           = "WAROENG KOPI JONG";
$nama_perusahaan = "WAROENG KOPI JONG";
$ep = "";
$pp = "";

$hp_penerima = "081617568675";
function sms($nomor,$text) {
    exec('D:\XAMPP\htdocs\distrobgc\gammu\bin\gammu-smsd-inject.exe -c D:\XAMPP\htdocs\distrobgc\gammu\bin\smsdrc EMS '.hp($nomor).' -text "'.$text.'"');
}
?>
<script type="text/javascript">
    var txt="<?php echo $title; ?>";
    // var speed=150;
    // var SULE_SS=null;
    function move() { 
    	document.title=txt;
    	// txt=txt.substring(1,txt.length)+txt.charAt(0);
    	// fresh=setTimeout("move()",speed);
    }
    move();
</script>