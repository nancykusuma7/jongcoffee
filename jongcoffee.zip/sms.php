<?php
include"config.php";
include 'assets/lib/function.php';

if ((isset($_POST["submit"])) && ($_POST["submit"] == "Kirim SMS")) {

$noTujuan = $_POST['nohp'];
$text = "TEST SMS GATEWAY";

if (strlen($noTujuan) < 4) {
    sms(hp($hp_penerima),$text);
} else {
    sms(hp($noTujuan),$text);
}

// exec('F:\XAMPP\htdocs\griyafarma\gammu\bin\gammu-smsd-inject.exe -c F:\XAMPP\htdocs\griyafarma\gammu\bin\smsdrc EMS '.$noTujuan.' -text "'.$message.'"');
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/custom.css">
        <link rel="stylesheet" href="assets/css/fontawesome/css/font-awesome.min.css">
    </head>
    <body>
        
        <form method="post" >
        Tujuan : <input type="text" name="nohp" value=""><br>
        <input type="submit" name="submit" value="Kirim SMS">
        </form>

        <!-- JavaScript
        ================================================== -->
        <script src="assets/js/jquery-min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
    </body>
</html>