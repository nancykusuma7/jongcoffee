<div class="col-md-3">
  
    
<div class="list-group">
<div class="list-group-item"><div id="judul">Waroeng Kami</div></div>
<div class="list-group-item">
<div id="widget"><div>
<li class="li-class-no">Jl. Semarang No. 192</li>
<li class="li-class-no">Kota Pekalongan</li>
<li class="li-class-no">Telp. 087 1027 7955</li>
<li class="li-class-no">Wa 087 1027 7955</li>
</ul>
</div>
    
 </div>
        </div>
</div>
<div class="list-group">
<div class="list-group-item"><div id="judul">Jam Buka Waroeng</div></div>
<div class="list-group-item">
<div id="widget">
<ul>
    <li class="li-class">Senin s/d Sabtu : 08.00 s/d 23.00 WIB</li>
    <li class="li-class">Minggu : 09.00 s/d 13.00 WIB</li>
</ul>
<tr>
  <td valign="top"><div align="center">
    <h3>Hari Minggu Tetap Buka</h3>
  </div></td>
</tr>

</div>
</div>

        
        </div>
        </div>
        </div>
