<?php 
session_start();
$_SESSION['meja']='';
include 'config.php';
include 'koneksi.php';
include 'assets/lib/function.php';
include 'query_header.php';


$sql_produk_home = $con->query("SELECT * FROM meja");
$row_produk_home = $sql_produk_home->fetch(PDO::FETCH_LAZY);
$trow_produk_home = $sql_produk_home->rowCount();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="shortcut icon" href="assets/images/icon.jpg" />
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/toko.css">
        <link rel="stylesheet" href="assets/fontawesome/css/font-awesome.min.css">
    </head>
    <body>
    <div class="container">

        <?php include 'header.php'; ?>

            

                

                
    <div class="col-md-9"> 
     
      <div class="row"> 

        <?php do{
                                    $kd_produk = $row_produk_home['kd_meja'];
                                    
                         ?>
        <a href="menu?meja=<?php echo $row_produk_home['nama_meja']; ?>"> 
        <div class="col-sm-3 col-lg-3 col-md-3"> 
          <div class="thumbnail"> 
            <div class="gproduk"> <img src="assets/images/menu/meja.png" width="100%"> 
            </div>
            <div class="caption"> 
              <!-- <h4 class="pull-right">$24.99</h4> -->
              <p><div align="center" style="font-size: 16px"><b style="color: black"> <?php echo $row_produk_home['nama_meja']; ?> </div></p>
            </div>
            
          </div>
        </div>
        </a> 
        <?php }while($row_produk_home = $sql_produk_home->fetch()); ?>

  
  </div>

    </div>
<?php include 'sidebar.php' ?>
            </div>

        
        <!-- /.container -->

        <?php include 'footer.php'; ?>

        <!-- Bootstrap core JavaScript
        ================================================== -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/validasi.js"></script>
        <script src="assets/js/validasiinput.js"></script>
        <script src="assets/js/app.js"></script>
    </body>
</html>