


<div class="container-fluit footer">
    <div class="container">
        <footer>
            <div class="row">
                <center>
                    Copyright &copy; <?php echo date("Y"); ?> <a href="#"><?php echo $nama_perusahaan;?></a>
                    
                </center>
            </div>
        </footer>
    </div>
</div>
<!-- /.container -->