<?php 
include 'config.php';
include 'koneksi.php';
include 'assets/lib/function.php';
//include 'query_header.php';

// jika menekan tombol beli
if ((isset($_POST["beli"])) && ($_POST["beli"] == "y")) {

	$kd_menu    = $_POST['kd_menu'];
	$jml     = $_POST['jml'];
	//$ukuran       = $_POST['ukuran'];
	$harga = $_POST['harga'];
  $meja = $_SESSION['meja'];
  $jmlharga = $harga*$jml;
	//$kd_stok      = $_POST['kd_stok'];
	//$stok         = $_POST['stok'];

	//if ($jml_beli > $stok) {
	//$pesankonfirm =  "
  //                  <div class='alert alert-danger alert-dismissible animated fadeIn' //role='alert'>                        <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span>
  //                      </button>
  //                      <strong>Maaf!</strong> Barang yang anda beli melebihi stok
  //                  </div>
  //          ";
	//} else {

	// jika belum login
	//if (!isset($_SESSION['pelanggan'])) {
	//	$_SESSION['temp_kd_produk']    = $kd_produk;
	//	$_SESSION['temp_jml_beli']     = $jml_beli;
  //  $_SESSION['temp_ukuran']       = $ukuran;
	//	$_SESSION['temp_harga_produk'] = $harga_produk;
	//	$_SESSION['temp_kd_stok']      = $kd_stok;
	//	$_SESSION['temp_stok']         = $stok;
		// dialihkan ke halaman login
	//	$halaman = "login";

	//} else {
	//	$userid = $_SESSION['pelanggan'];
		include 'cek_status_faktur.php';

		$sql_cek = $con->query( "SELECT * FROM order_menu WHERE kd_menu='$kd_menu' AND meja='$meja'");
        $row_cek = $sql_cek->fetch ( );
        $trow_cek = $sql_cek->rowCount ();

        if (!empty($trow_cek)) {
            $jml = $row_cek['jml'];
            $kd_order = $row_cek['kd_order_menu'];

            // $con->exec("UPDATE stok SET stok=stok+'$stok_baru' WHERE kd_stok='$kd_stok' ");
            $con->exec("UPDATE order_menu SET jml='$jml' WHERE kd_order_menu='$kd_order'");
            // $con->exec("UPDATE stok SET stok=stok-$jml_beli WHERE kd_stok='$kd_stok' ");

        } else {
            // proses simpan ke table order_produk
            $con->exec("INSERT INTO order_menu (kd_pesanan, kd_menu, meja, harga, jml, jmlharga) 
                    VALUES (
                    '".$kd_pesanan."',
                    '".$kd_menu."',
                    '".$meja."',
                    '".$harga."',
                    '".$jml."',
                    '".$jmlharga."'
                    )");
            // $con->exec("UPDATE stok SET stok=stok-$jml_beli WHERE kd_stok='$kd_stok' ");
        }

        $halaman = "daftar_pembelian";
        header("Location: " . $halaman );
	}


	
 // end if tekan tombol


// jika tidak mendapatkan nilai kd_produk dari halaman sebelumnya
if (!isset($_GET['kd_menu'])) {

	// diambilkan nilai kd_produk yang dikirim ketika menekan tombol beli
	$kd_menu = $_POST['kd_menu'];


} else {
	$kd_menu = $_GET['kd_menu'];
}

$sql_detail_p = $con->query("SELECT * FROM menu WHERE kd_menu='$kd_menu' ");
$row_detail_p = $sql_detail_p->fetch(PDO::FETCH_LAZY);
$trow_detail_p = $sql_detail_p->rowCount();
$namemenu = $row_detail_p['nama_menu'];

$sql_warna = $con->query("SELECT kd_menu, nama_menu, foto FROM menu WHERE nama_menu='$namemenu' AND kd_menu!='$kd_menu'");
$row_warna = $sql_warna->fetch(PDO::FETCH_LAZY);
$trow_warna = $sql_warna->rowCount();


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- <link rel="icon" href="../images/favicon.ico"> -->

        <title></title>
        <link rel="shortcut icon" href="assets/images/icon.jpg" />
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/toko.css">
        <link rel="stylesheet" href="assets/fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/jquery.bootstrap-touchspin.min.css">
        <link rel="stylesheet" href="assets/css/smoothproducts.css">
    </head>
    <body>

        <div class="container">
        <?php include 'header.php'; ?>


            <div class="row">

                

                
    <div class="col-md-9"> 
      <div id="judul">Detail Menu</div>
      <?php if((!empty($trow_detail_p)) && (!empty($kd_menu))): ?>
      <ol class="breadcrumb">
        <li><a href="./">Home</a></li>
        <li>Menu</li>
        <li class="active"> 
          <?php echo $row_detail_p['nama_menu']; ?>
        </li>
      </ol>
      <hr>
      <div class="row"> 
        <?php echo $pesankonfirm; ?>
        <!-- Foto
							================================================ -->
        <?php
								$sql_foto_slide = $con->query("SELECT * FROM foto_menu WHERE kd_menu='$kd_menu' ");
								$row_foto_slide = $sql_foto_slide->fetch();
								$trow_foto_slide = $sql_foto_slide->rowCount();
							?>
        <div class="preview col-sm-4"> 
          
          
            <img src="assets/images/menu/<?php echo $row_detail_p['foto']; ?>" alt="">
          
        </div>
        <form method="POST" >
          <!-- Detail
							================================================ -->
          <div class="col-sm-8"> 
            <h3> 
              <?php echo $row_detail_p['nama_menu']; ?>
              
            </h3>
            <p style="color: #FA7455; font-size: 20px"> <b> 
              Harga : Rp. <?php echo $hmenu = $row_detail_p['harga']; ?>
              
              </b> </p>
            <!-- Pilihan Jumlah Beli
								======================================================================================== -->
            <div class="form-horizontal row"> 
              <div class="form-group col-sm-6"> 
                <label class="control-label col-sm-7" for="jml_beli">Jumlah Pesan</label>
                <div class="col-sm-9"> 
                  <input id="jml" type="text" name="jml" value="1" class="text-center">
                </div>
              </div>
            </div>
            <!-- Tombol Beli
								======================================================================================== -->
            <button type="submit" name="beli" value="y" class="btn btn-warning"> 
            <i class="fa fa-shopping-cart" aria-hidden="true"></i> Pesan </button>
            <input type="hidden" name="kd_menu" value="<?php echo $kd_menu; ?>">
            <input type="hidden" name="harga" value="<?php echo $hmenu; ?>">
            <input id="kd_stok" type="hidden" name="kd_stok" value="0">
            <h4 style="margin-top: 30px">Deskripsi</h4>
            <hr>
            <?php echo $row_detail_p['deskripsi']; ?>
          </div>
        </form>
      </div>
      <!-- Jika tidak ada barang
					================================================ -->
      <?php else: ?>
      <p class="well text-center"> Maaf, barang tidak ditemukan. </p>
      <?php endif; ?>
     
      <!-- Barang sejenis
					================================================ -->
      </div>
      
<?php include 'sidebar.php' ?>
            </div>

        </div>
        <!-- /.container -->
		

        <?php include 'footer.php'; ?>

        <!-- Bootstrap core JavaScript
        ================================================== -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/validasi.js"></script>
        <script src="assets/js/validasiinput.js"></script>
        <script src="assets/js/jquery.bootstrap-touchspin.min.js"></script>

      
        <script>
		    $("#jml").TouchSpin({
		    	min: 1,
		    	max: 100,
		    	buttondown_class: 'btn btn-default',
		    	buttonup_class: 'btn btn-default'
		    });
		</script>
		<script type="text/javascript" src="assets/js/smoothproducts.min.js"></script>
		
    </body>
</html>