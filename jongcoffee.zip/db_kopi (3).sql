-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2020 at 11:55 AM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kopi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `nama_admin` varchar(50) NOT NULL,
  `alamat_admin` text NOT NULL,
  `tlp_admin` varchar(13) NOT NULL,
  `userid` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`nama_admin`, `alamat_admin`, `tlp_admin`, `userid`) VALUES
('Nancy Kusuma Widya', 'Perumahan Griya Tukul Alaska', '085740000001', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `foto_menu`
--

CREATE TABLE `foto_menu` (
  `kd_menu` int(11) NOT NULL,
  `foto` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `foto_menu`
--

INSERT INTO `foto_menu` (`kd_menu`, `foto`) VALUES
(5, 'menu0901200830271.jpg'),
(6, 'menu1601200629081.jpg'),
(7, 'menu1601200630051.jpg'),
(8, 'menu1601200630531.jpg'),
(9, 'menu1601200632261.jpg'),
(10, 'menu1601200633091.jpg'),
(11, 'menu1601200634381.jpg'),
(12, 'menu1601200635441.jpg'),
(13, 'menu1601200636591.jpg'),
(14, 'menu1601200637591.jpg'),
(15, 'menu1601200638461.jpg'),
(16, 'menu1601200642051.jpg'),
(17, 'menu1601200643331.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `inbox`
--

CREATE TABLE `inbox` (
  `kd_inbox` int(11) NOT NULL,
  `pengirim` varchar(30) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `tujuan` enum('Admin','Pelanggan') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inbox`
--

INSERT INTO `inbox` (`kd_inbox`, `pengirim`, `judul`, `tujuan`) VALUES
(1, 'Meja 1', 'Kopi', 'Admin'),
(2, 'Meja 6', 'meja 5', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `inbox_detail`
--

CREATE TABLE `inbox_detail` (
  `kd_inbox_detail` int(11) NOT NULL,
  `kd_inbox` int(11) NOT NULL,
  `pengirim` varchar(30) NOT NULL,
  `pesan` text NOT NULL,
  `tgl` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('N','R') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inbox_detail`
--

INSERT INTO `inbox_detail` (`kd_inbox_detail`, `kd_inbox`, `pengirim`, `pesan`, `tgl`, `status`) VALUES
(2, 1, 'Meja 1', 'Macam2 KOpi', '2020-01-07 09:29:05', 'N'),
(4, 1, 'admin', 'Banyak', '2020-01-07 09:44:10', 'N'),
(5, 2, 'Meja 6', 'pesanan lama tdk di antar', '2020-01-16 02:26:04', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `meja`
--

CREATE TABLE `meja` (
  `kd_meja` int(11) NOT NULL,
  `nama_meja` varchar(20) NOT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meja`
--

INSERT INTO `meja` (`kd_meja`, `nama_meja`, `gambar`) VALUES
(1, 'Meja 1', ''),
(2, 'Meja 2', ''),
(3, 'Meja 3', ''),
(4, 'Meja 4', ''),
(5, 'Meja 5', ''),
(6, 'Meja 6', '');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `kd_menu` int(11) NOT NULL,
  `nama_menu` varchar(100) NOT NULL,
  `kategori` varchar(30) NOT NULL,
  `harga` double NOT NULL,
  `deskripsi` longtext,
  `foto` varchar(30) DEFAULT 'produk.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`kd_menu`, `nama_menu`, `kategori`, `harga`, `deskripsi`, `foto`) VALUES
(5, 'Coffee Frappe', 'Minuman', 17000, '<p>Nikmat</p>\r\n', 'menu0901200830271.jpg'),
(6, 'Nasi Goreng', 'Makanan', 15000, '<p>enak</p>\r\n', 'menu1601200629081.jpg'),
(7, 'Spagethi ', 'Makanan', 15000, '<p>enak</p>\r\n', 'menu1601200630051.jpg'),
(8, 'Iga Bakar', 'Makanan', 20000, '<p>enakk</p>\r\n', 'menu1601200630531.jpg'),
(9, 'Cokeis Blend', 'Minuman', 12000, '', 'menu1601200632261.jpg'),
(10, 'Ayam Goreng Saus Padang', 'Makanan', 16000, '', 'menu1601200633091.jpg'),
(11, 'Ayam Saus Mentega', 'Makanan', 13000, '', 'menu1601200634381.jpg'),
(12, 'Otak Otak', 'Makanan', 10000, '', 'menu1601200635441.jpg'),
(13, 'Black Forest', 'Minuman', 15000, '', 'menu1601200636591.jpg'),
(14, 'Tiramisu Blend', 'Minuman', 15000, '', 'menu1601200637591.jpg'),
(15, 'Blue Ocean', 'Minuman', 12000, '', 'menu1601200638461.jpg'),
(16, 'Lemon Tea', 'Minuman', 12000, '', 'menu1601200642051.jpg'),
(17, 'Hot Choco', 'Minuman', 13000, '', 'menu1601200643331.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order_menu`
--

CREATE TABLE `order_menu` (
  `kd_order_menu` int(11) NOT NULL,
  `kd_pesanan` int(30) NOT NULL,
  `kd_menu` int(11) NOT NULL,
  `meja` varchar(20) NOT NULL,
  `harga` double NOT NULL,
  `jml` double NOT NULL,
  `jmlharga` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_menu`
--

INSERT INTO `order_menu` (`kd_order_menu`, `kd_pesanan`, `kd_menu`, `meja`, `harga`, `jml`, `jmlharga`) VALUES
(4, 1578375369, 1, 'Meja 3', 75000, 3, 225000),
(6, 1578384578, 1, 'Meja 1', 75000, 2, 150000),
(8, 1578967910, 5, 'Meja 4', 17000, 1, 17000),
(9, 1578967910, 1, 'Meja 4', 12000, 1, 12000),
(10, 1578967910, 2, 'Meja 4', 15000, 1, 15000),
(11, 1578665786, 2, 'Meja 2', 15000, 4, 60000),
(12, 1578665786, 4, 'Meja 2', 14000, 3, 42000),
(13, 1579081910, 4, 'Meja 3', 14000, 7, 98000),
(14, 1579103974, 3, 'Meja 1', 13000, 3, 39000),
(15, 1579103974, 4, 'Meja 1', 14000, 4, 56000),
(16, 1579104121, 2, 'Meja 1', 15000, 1, 15000),
(17, 1579104302, 5, 'Meja 1', 17000, 2, 34000),
(18, 1579104356, 3, 'Meja 2', 13000, 4, 52000),
(19, 1579129893, 2, 'Meja 3', 15000, 1, 15000),
(20, 1579129849, 3, 'Meja 4', 13000, 1, 13000),
(21, 1579129579, 7, 'Meja 1', 15000, 1, 15000),
(22, 1579129849, 10, 'Meja 4', 16000, 1, 16000),
(23, 1579129579, 6, 'Meja 1', 15000, 1, 15000),
(24, 1579129579, 9, 'Meja 1', 12000, 1, 12000),
(25, 1579137981, 8, 'Meja 2', 20000, 1, 20000),
(26, 1579140998, 6, 'Meja 5', 15000, 1, 15000),
(27, 1579140998, 7, 'Meja 5', 15000, 1, 15000),
(28, 1579140998, 5, 'Meja 5', 17000, 2, 34000),
(29, 1579140998, 13, 'Meja 5', 15000, 2, 30000),
(30, 1579141288, 10, 'Meja 6', 16000, 4, 64000),
(31, 1579141288, 11, 'Meja 6', 13000, 3, 39000),
(32, 1579141288, 15, 'Meja 6', 12000, 100, 1200000);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `nama_plg` varchar(50) NOT NULL,
  `alamat_plg` text NOT NULL,
  `tlp_plg` varchar(13) NOT NULL,
  `userid` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`nama_plg`, `alamat_plg`, `tlp_plg`, `userid`) VALUES
('aa', 'aa', '12345', 'aa'),
('b', 'b', '123444', 'b'),
('budi', 'manggis', '1234567', 'budi'),
('m', 'm', '111111', 'm');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `kd_pesanan` int(30) NOT NULL,
  `meja` varchar(20) NOT NULL,
  `bayar` double DEFAULT NULL,
  `tgl` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pembayaran` enum('Tunai','Transfer') NOT NULL DEFAULT 'Transfer',
  `konfirm` enum('Sudah','Belum') NOT NULL DEFAULT 'Belum',
  `userid` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`kd_pesanan`, `meja`, `bayar`, `tgl`, `pembayaran`, `konfirm`, `userid`) VALUES
(1579129579, 'Meja 1', 30000, '2020-01-15 23:58:12', 'Transfer', 'Belum', 'm'),
(1579129849, 'Meja 4', NULL, '2020-01-15 23:10:49', 'Transfer', 'Belum', ''),
(1579129893, 'Meja 3', 20000, '2020-01-15 23:14:50', 'Transfer', 'Sudah', 'aa'),
(1579130414, 'Meja 3', NULL, '2020-01-15 23:20:14', 'Transfer', 'Belum', ''),
(1579137981, 'Meja 2', NULL, '2020-01-16 01:26:21', 'Transfer', 'Belum', ''),
(1579140998, 'Meja 5', 100000, '2020-01-16 02:19:25', 'Transfer', 'Sudah', 'budi'),
(1579141288, 'Meja 6', 330000, '2020-01-16 02:29:13', 'Transfer', 'Belum', 'b');

-- --------------------------------------------------------

--
-- Table structure for table `stok`
--

CREATE TABLE `stok` (
  `kd_stok` int(11) NOT NULL,
  `kd_menu` int(11) NOT NULL,
  `stok` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stok`
--

INSERT INTO `stok` (`kd_stok`, `kd_menu`, `stok`) VALUES
(57, 5, 50),
(58, 6, 50),
(59, 7, 30),
(60, 8, 50),
(61, 9, 50),
(62, 10, 50),
(63, 11, 50),
(64, 12, 50),
(65, 13, 50),
(66, 14, 50),
(67, 15, 50),
(68, 16, 50),
(69, 17, 50);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `tipe` enum('Admin','Pelanggan') NOT NULL,
  `status` enum('Y','N') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `password`, `tipe`, `status`) VALUES
('admin', 'admin', 'Admin', 'Y'),
('andhika@gmail.com', 'andhika', 'Pelanggan', 'Y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `inbox`
--
ALTER TABLE `inbox`
  ADD PRIMARY KEY (`kd_inbox`);

--
-- Indexes for table `inbox_detail`
--
ALTER TABLE `inbox_detail`
  ADD PRIMARY KEY (`kd_inbox_detail`);

--
-- Indexes for table `meja`
--
ALTER TABLE `meja`
  ADD PRIMARY KEY (`kd_meja`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`kd_menu`);

--
-- Indexes for table `order_menu`
--
ALTER TABLE `order_menu`
  ADD PRIMARY KEY (`kd_order_menu`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`kd_pesanan`);

--
-- Indexes for table `stok`
--
ALTER TABLE `stok`
  ADD PRIMARY KEY (`kd_stok`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inbox`
--
ALTER TABLE `inbox`
  MODIFY `kd_inbox` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `inbox_detail`
--
ALTER TABLE `inbox_detail`
  MODIFY `kd_inbox_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `meja`
--
ALTER TABLE `meja`
  MODIFY `kd_meja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `kd_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `order_menu`
--
ALTER TABLE `order_menu`
  MODIFY `kd_order_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `stok`
--
ALTER TABLE `stok`
  MODIFY `kd_stok` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
