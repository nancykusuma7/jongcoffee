<!DOCTYPE html>
<html>
	<head>
		<title>
			ERROR 404
		</title>
		<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="/khanza/assets/css/font-face.css">
		<link rel="stylesheet" href="/khanza/assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="/khanza/assets/css/animate.css">
	</head>
	<body style="padding-top: 70px; background-color: #164a80; font-family: 'Ubuntu'">
		<div class="container animated fadeInDown">
			<div style="margin: 0px auto; width: 480px; padding-top: 50px;">
				<img src="/khanza/assets/images/404.png" width="480" height="278" alt=""/>
			</div>
			<div style="text-align: center; margin-top: 30px;">
				<button type="button" class="btn btn-danger btn-xs" onclick="self.history.back()"><span class="glyphicon glyphicon-chevron-left"></span> Kembali ke halaman sebelumnya</button>
			</div>
		</div>
	</body>
</html>